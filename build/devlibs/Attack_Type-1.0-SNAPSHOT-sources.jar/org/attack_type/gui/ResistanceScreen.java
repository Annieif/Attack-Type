package org.attack_type.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.PacketByteBuf;
import org.attack_type.api.AttackType;
import org.attack_type.api.ResistanceProfile;
import org.attack_type.api.SinType;
import org.attack_type.network.ClientResistanceCache;
import org.attack_type.network.ModPackets;

import java.util.ArrayList;
import java.util.List;

/**
 * 抗性配置 GUI。
 * <p>
 * 打开后显示 3 种物理攻击类型 + 7 种罪孽属性的当前抗性值，
 * 可编辑每个抗性值（范围 0.00~5.00），点击 Apply 发送到服务端。
 * 底部显示全部抗性乘积，验证是否 ≥1.0。
 * <p>
 * 打开方式：按 U 键。
 */
public class ResistanceScreen extends Screen {
    private ResistanceProfile profile;
    private final List<TextFieldWidget> physicalFields = new ArrayList<>();
    private final List<TextFieldWidget> sinFields = new ArrayList<>();

    private static final int FIELD_W = 72;
    private static final int FIELD_H = 18;
    private static final int LABEL_W = 64;
    private static final int ROW_H = 18;
    private static final int SECTION_GAP = 8;
    /** 抗性值上限 */
    private static final float CLAMP_MAX = 5.0f;

    /**
     * 创建抗性配置 GUI，从 {@link ClientResistanceCache} 加载当前配置。
     */
    public ResistanceScreen() {
        super(Text.translatable("screen.attack_type.resistance"));
        this.profile = new ResistanceProfile();
        ResistanceProfile cached = ClientResistanceCache.getProfile();
        if (cached != null) copyProfile(cached, this.profile);
    }

    @Override
    protected void init() {
        super.init();
        int centerX = width / 2;
        int y = 24;

        int totalHalf = (LABEL_W + 8 + FIELD_W + 8 + 48) / 2;
        int labelX = centerX - totalHalf;
        int fieldX = labelX + LABEL_W + 8;

        AttackType[] atypes = getAttackTypes();
        SinType[] stypes = SinType.values();
        int rows1 = atypes.length;
        int rows2 = stypes.length;

        for (int i = 0; i < atypes.length; i++) {
            int fy = y + i * ROW_H;
            TextFieldWidget tf = new TextFieldWidget(textRenderer, fieldX, fy, FIELD_W, FIELD_H,
                    Text.literal(atypes[i].name()));
            tf.setDrawsBackground(false);
            tf.setText(String.format("%.2f", profile.getPhysicalResistance(atypes[i])));
            addDrawableChild(tf);
            physicalFields.add(tf);
        }

        y += rows1 * ROW_H + SECTION_GAP;
        int sinStartY = y;

        for (int i = 0; i < stypes.length; i++) {
            int fy = y + i * ROW_H;
            TextFieldWidget tf = new TextFieldWidget(textRenderer, fieldX, fy, FIELD_W, FIELD_H,
                    Text.literal(stypes[i].name()));
            tf.setDrawsBackground(false);
            tf.setText(String.format("%.2f", profile.getSinResistance(stypes[i])));
            addDrawableChild(tf);
            sinFields.add(tf);
        }

        y = sinStartY + rows2 * ROW_H + SECTION_GAP;
        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.attack_type.apply"), b -> applyChanges())
                .dimensions(centerX - 50, y, 100, 20).build());
    }

    /**
     * @return 排除 NONE 的物理攻击类型数组
     */
    private AttackType[] getAttackTypes() {
        return java.util.Arrays.stream(AttackType.values())
                .filter(t -> t != AttackType.NONE).toArray(AttackType[]::new);
    }

    /**
     * 裁剪抗性值到 [0, CLAMP_MAX] 范围并保留两位小数。
     */
    private float clamp(float v) {
        if (v < 0f) return 0f;
        if (v > CLAMP_MAX) return CLAMP_MAX;
        return Math.round(v * 100f) / 100f;
    }

    private void collectInputs() {
        AttackType[] atypes = getAttackTypes();
        for (int i = 0; i < atypes.length && i < physicalFields.size(); i++) {
            try {
                float v = Float.parseFloat(physicalFields.get(i).getText());
                profile.setPhysicalResistance(atypes[i], clamp(v));
            } catch (NumberFormatException ignored) {}
        }
        SinType[] stypes = SinType.values();
        for (int i = 0; i < stypes.length && i < sinFields.size(); i++) {
            try {
                float v = Float.parseFloat(sinFields.get(i).getText());
                profile.setSinResistance(stypes[i], clamp(v));
            } catch (NumberFormatException ignored) {}
        }
    }

    /**
     * 收集输入并发送抗性更新包到服务端。
     */
    private void applyChanges() {
        collectInputs();
        ClientResistanceCache.setProfile(profile);
        PacketByteBuf buf = PacketByteBufs.create();
        for (AttackType type : AttackType.values())
            if (type != AttackType.NONE) buf.writeFloat(profile.getPhysicalResistance(type));
        for (SinType type : SinType.values()) buf.writeFloat(profile.getSinResistance(type));
        buf.writeFloat(profile.getTotalProduct());
        ClientPlayNetworking.send(ModPackets.RESISTANCE_UPDATE, buf);
        close();
    }

    private static float tryParse(String s) {
        try { return Float.parseFloat(s); }
        catch (NumberFormatException e) { return Float.NaN; }
    }

    private void drawFieldBorder(DrawContext ctx, TextFieldWidget tf, boolean overflow) {
        int x = tf.getX();
        int y = tf.getY();
        int w = tf.getWidth();
        int h = tf.getHeight();
        int border = overflow ? 0xFFFF5555 : 0xFF888888;
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, border);
        ctx.fill(x, y, x + w, y + h, 0xFF111111);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        collectInputs();
        renderBackground(context);

        int centerX = width / 2;
        int y = 24;

        int totalHalf = (LABEL_W + 8 + FIELD_W + 8 + 48) / 2;
        int labelX = centerX - totalHalf;
        int fieldX = labelX + LABEL_W + 8;
        int statusX = fieldX + FIELD_W + 8;

        context.drawCenteredTextWithShadow(textRenderer, title, centerX, 8, 0xFFFFFF);

        double product = 1.0;
        AttackType[] atypes = getAttackTypes();
        SinType[] stypes = SinType.values();

        int totalRows = atypes.length + stypes.length;
        boolean[] overflows = new boolean[totalRows];
        float[] rawValues = new float[totalRows];
        int[] lyTexts = new int[totalRows];

        for (int i = 0; i < atypes.length; i++) {
            int ly = y + i * ROW_H;
            TextFieldWidget tf = physicalFields.get(i);
            float raw = tryParse(tf.getText());
            float v = profile.getPhysicalResistance(atypes[i]);
            float display = !Float.isNaN(raw) ? raw : v;
            product *= !Float.isNaN(raw) ? raw : v;
            boolean overflow = !Float.isNaN(raw) && (raw < 0f || raw > CLAMP_MAX);
            overflows[i] = overflow;
            rawValues[i] = raw;

            drawFieldBorder(context, tf, overflow);

            Text label = Text.translatable("attack_type.attack_type." + atypes[i].name().toLowerCase());
            int lyText = ly + (FIELD_H - 8) / 2;
            lyTexts[i] = lyText;
            context.drawTextWithShadow(textRenderer, label, labelX, lyText, 0xCCCCCC);

            Text status = Text.translatable(ResistanceProfile.getResistanceLabel(display));
            context.drawTextWithShadow(textRenderer, status, statusX, lyText,
                    display >= 1.0f ? 0xFF8888 : 0x88FF88);
        }

        y += atypes.length * ROW_H + SECTION_GAP;
        int sinStartY = y;

        for (int i = 0; i < stypes.length; i++) {
            int idx = atypes.length + i;
            int ly = y + i * ROW_H;
            TextFieldWidget tf = sinFields.get(i);
            float raw = tryParse(tf.getText());
            float v = profile.getSinResistance(stypes[i]);
            float display = !Float.isNaN(raw) ? raw : v;
            product *= !Float.isNaN(raw) ? raw : v;
            boolean overflow = !Float.isNaN(raw) && (raw < 0f || raw > CLAMP_MAX);
            overflows[idx] = overflow;
            rawValues[idx] = raw;

            drawFieldBorder(context, tf, overflow);

            Text label = Text.translatable("sin.attack_type." + stypes[i].name().toLowerCase());
            int lyText = ly + (FIELD_H - 8) / 2;
            lyTexts[idx] = lyText;
            context.drawTextWithShadow(textRenderer, label, labelX, lyText, 0xCCCCCC);

            Text status = Text.translatable(ResistanceProfile.getResistanceLabel(display));
            context.drawTextWithShadow(textRenderer, status, statusX, lyText,
                    display >= 1.0f ? 0xFF8888 : 0x88FF88);
        }

        y = sinStartY + stypes.length * ROW_H + SECTION_GAP - 4;

        boolean ok = product >= 1.0;
        Text status = Text.translatable(ok ? "screen.attack_type.ok" : "screen.attack_type.lt1");
        Text prodText = Text.translatable("screen.attack_type.total_product_line", product, status);
        int tw = textRenderer.getWidth(prodText);
        context.drawTextWithShadow(textRenderer, prodText,
                centerX - tw / 2, y, ok ? 0x66FF66 : 0xFF6666);

        super.render(context, mouseX, mouseY, delta);

        for (int i = 0; i < totalRows; i++) {
            if (overflows[i]) {
                float raw = rawValues[i];
                Text ovText = Text.literal(raw > CLAMP_MAX ? ">" : "<");
                Text stText = Text.translatable("screen.attack_type.vulnerable");
                int stW = textRenderer.getWidth(stText);
                context.drawTextWithShadow(textRenderer, ovText, statusX + stW + 2, lyTexts[i], 0xFFFF4444);
            }
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    /**
     * 深拷贝抗性配置。
     */
    private static void copyProfile(ResistanceProfile from, ResistanceProfile to) {
        for (AttackType type : AttackType.values())
            if (type != AttackType.NONE) to.setPhysicalResistance(type, from.getPhysicalResistance(type));
        for (SinType type : SinType.values()) to.setSinResistance(type, from.getSinResistance(type));
        to.setTotalProduct(from.getTotalProduct());
    }
}