package org.attack_type.gui;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.attack_type.api.AttackType;
import org.attack_type.api.ResistanceProfile;
import org.attack_type.api.SinType;
import org.attack_type.network.ClientResistanceCache;
import org.attack_type.network.ModPackets;

public class ResistanceScreen extends class_437 {
    private ResistanceProfile profile;
    private static final int ROW_HEIGHT = 22;
    private static final int START_Y = 30;
    private static final int COL_DEC = 260;
    private static final int COL_INC = 300;

    public ResistanceScreen() {
        super(class_2561.method_43471("screen.attack_type.resistance"));
        this.profile = new ResistanceProfile();
        ResistanceProfile cached = ClientResistanceCache.getProfile();
        if (cached != null) {
            copyProfile(cached, this.profile);
        }
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int y = START_Y;

        method_37063(class_4185.method_46430(class_2561.method_43471("screen.attack_type.physical"), b -> {}).method_46434(10, y - 16, 80, 16).method_46431());

        for (AttackType type : AttackType.values()) {
            if (type == AttackType.NONE) continue;
            final AttackType at = type;
            final int rowY = y;
            method_37063(class_4185.method_46430(class_2561.method_43470("-0.1"), b -> adjustPhysical(at, -0.1f))
                    .method_46434(COL_DEC, rowY, 40, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("+0.1"), b -> adjustPhysical(at, 0.1f))
                    .method_46434(COL_INC, rowY, 40, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("-0.01"), b -> adjustPhysical(at, -0.01f))
                    .method_46434(COL_DEC + 50, rowY, 40, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("+0.01"), b -> adjustPhysical(at, 0.01f))
                    .method_46434(COL_INC + 50, rowY, 40, 20).method_46431());
            y += ROW_HEIGHT;
        }

        y += 8;
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.attack_type.sin"), b -> {}).method_46434(10, y - 16, 80, 16).method_46431());

        for (SinType type : SinType.values()) {
            final SinType st = type;
            final int rowY = y;
            method_37063(class_4185.method_46430(class_2561.method_43470("-0.1"), b -> adjustSin(st, -0.1f))
                    .method_46434(COL_DEC, rowY, 40, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("+0.1"), b -> adjustSin(st, 0.1f))
                    .method_46434(COL_INC, rowY, 40, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("-0.01"), b -> adjustSin(st, -0.01f))
                    .method_46434(COL_DEC + 50, rowY, 40, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("+0.01"), b -> adjustSin(st, 0.01f))
                    .method_46434(COL_INC + 50, rowY, 40, 20).method_46431());
            y += ROW_HEIGHT;
        }

        y += 8;
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.attack_type.apply"), b -> applyChanges())
                .method_46434(field_22789 / 2 - 50, y, 100, 20).method_46431());
    }

    private void adjustPhysical(AttackType type, float delta) {
        float current = profile.getPhysicalResistance(type);
        float newValue = current + delta;
        newValue = Math.round(newValue * 100.0f) / 100.0f;
        if (newValue < 0.0f || newValue > 5.0f) return;
        profile.setPhysicalResistance(type, newValue);
    }

    private void adjustSin(SinType type, float delta) {
        float current = profile.getSinResistance(type);
        float newValue = current + delta;
        newValue = Math.round(newValue * 100.0f) / 100.0f;
        if (newValue < 0.0f || newValue > 5.0f) return;
        profile.setSinResistance(type, newValue);
    }

    private void applyChanges() {
        ClientResistanceCache.setProfile(profile);

        class_2540 buf = PacketByteBufs.create();
        for (AttackType type : AttackType.values()) {
            if (type != AttackType.NONE) {
                buf.writeFloat(profile.getPhysicalResistance(type));
            }
        }
        for (SinType type : SinType.values()) {
            buf.writeFloat(profile.getSinResistance(type));
        }
        buf.writeFloat(profile.getTotalProduct());
        ClientPlayNetworking.send(ModPackets.RESISTANCE_UPDATE, buf);

        method_25419();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        super.method_25394(context, mouseX, mouseY, delta);

        int y = START_Y;
        context.method_27534(field_22793, field_22785, field_22789 / 2, 8, 0xFFFFFF);

        context.method_27534(field_22793,
                class_2561.method_43469("screen.attack_type.total_product", String.format("%.2f", profile.getTotalProduct())),
                field_22789 / 2, 20, 0xAAAAAA);

        for (AttackType type : AttackType.values()) {
            if (type == AttackType.NONE) continue;
            float value = profile.getPhysicalResistance(type);
            String label = class_2561.method_43471("attack_type.attack_type." + type.name().toLowerCase()).getString();
            context.method_27535(field_22793,
                    class_2561.method_43470(label + ": " + String.format("%.2f", value) + " (" + profile.getResistanceLabel(type) + ")"),
                    10, y + 6, 0xFFFFFF);
            y += ROW_HEIGHT;
        }

        y += 8;

        for (SinType type : SinType.values()) {
            float value = profile.getSinResistance(type);
            String label = class_2561.method_43471("sin.attack_type." + type.name().toLowerCase()).getString();
            context.method_27535(field_22793,
                    class_2561.method_43470(label + ": " + String.format("%.2f", value) + " (" + profile.getResistanceLabel(type) + ")"),
                    10, y + 6, 0xFFFFFF);
            y += ROW_HEIGHT;
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static void copyProfile(ResistanceProfile from, ResistanceProfile to) {
        for (AttackType type : AttackType.values()) {
            if (type != AttackType.NONE) {
                to.setPhysicalResistance(type, from.getPhysicalResistance(type));
            }
        }
        for (SinType type : SinType.values()) {
            to.setSinResistance(type, from.getSinResistance(type));
        }
        to.setTotalProduct(from.getTotalProduct());
    }
}