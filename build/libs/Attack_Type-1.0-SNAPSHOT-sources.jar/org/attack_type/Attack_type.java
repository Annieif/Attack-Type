package org.attack_type;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1309;
import org.attack_type.component.ResistanceManager;
import org.attack_type.enchantment.ModEnchantments;
import org.attack_type.network.NetworkHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Attack_type implements ModInitializer {
    public static final String MOD_ID = "attack_type";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModEnchantments.initialize();
        NetworkHandler.registerServer();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            NetworkHandler.sendResistanceSync(handler.field_14140);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ResistanceManager.removeProfile(handler.field_14140.method_5667());
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            server.method_3760().method_14571().forEach(player -> {
                ResistanceManager.tickEntityResistance(player, server.method_30002().method_8510());
            });
            server.method_3738().forEach(world -> {
                world.method_27909().forEach(entity -> {
                    if (entity instanceof class_1309 living) {
                        ResistanceManager.tickEntityResistance(living, world.method_8510());
                    }
                });
            });
        });

        LOGGER.info("Attack Type mod initialized!");
    }
}