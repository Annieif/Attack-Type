package org.attack_type.fragment;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1438;
import net.minecraft.class_1452;
import net.minecraft.class_1548;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1831;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.entity.passive.*;
import net.minecraft.item.*;
import org.attack_type.api.SinType;
import org.attack_type.config.ModConfig;
import org.attack_type.network.NetworkHandler;

import java.util.*;

/**
 * 罪孽碎片获取系统。
 * <p>
 * 为 7 种罪孽属性提供独立的碎片获取方式，每种罪孽体现不同的「性格」：
 * <ul>
 *   <li>{@link SinType#WRATH 暴怒} — 连杀追踪</li>
 *   <li>{@link SinType#LUST 色欲} — 繁殖与变异</li>
 *   <li>{@link SinType#SLOTH 怠惰} — 静止与睡眠</li>
 *   <li>{@link SinType#GLUTTONY 暴食} — 进食</li>
 *   <li>{@link SinType#GLOOM 忧郁} — 受伤与目击</li>
 *   <li>{@link SinType#PRIDE 傲慢} — 成就与生产</li>
 *   <li>{@link SinType#ENVY 嫉妒} — 攀比与目击</li>
 * </ul>
 */
public class SinFragmentAcquisition {

    /** 上次击杀时间（WRATH） */
    private static final Map<UUID, Long> LAST_KILL_TIME = new HashMap<>();
    /** 玩家上一帧位置（SLOTH AFK检测） */
    private static final Map<UUID, class_243> LAST_POS = new HashMap<>();
    /** AFK 累计 tick（SLOTH） */
    private static final Map<UUID, Integer> AFK_TICKS = new HashMap<>();
    /** 累计制作物品数（PRIDE） */
    private static final Map<UUID, Integer> CRAFTED_COUNT = new HashMap<>();
    /** 嫉妒攀比检测计时器（ENVY） */
    private static final Map<UUID, Integer> ENVY_TIMER = new HashMap<>();
    /** 鸡蛋上次使用时间（LUST 冷却） */
    private static final Map<UUID, Long> LAST_EGG_TIME = new HashMap<>();

    /**
     * 注册所有碎片获取事件监听器。在模组初始化时调用。
     */
    public static void register() {
        registerWrath();
        registerLust();
        registerSloth();
        registerGluttony();
        registerGloom();
        registerPride();
        registerEnvy();
    }

    // ==================== WRATH 暴怒 — 连杀 ====================

    private static void registerWrath() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity.method_37908().field_9236) return;
            if (source.method_5529() instanceof class_3222 player) {
                long now = entity.method_37908().method_8510();
                Long last = LAST_KILL_TIME.get(player.method_5667());
                if (last != null) {
                    long diff = now - last;
                    int bonus = 0;
                    int[] intervals = ModConfig.WRATH_KILL_CHAIN_INTERVALS;
                    int[] bonuses = ModConfig.WRATH_KILL_CHAIN_BONUSES;
                    for (int i = 0; i < intervals.length; i++) {
                        if (diff <= intervals[i] && bonus == 0) {
                            bonus = bonuses[i];
                        }
                    }
                    if (bonus > 0) {
                        SinFragmentManager.addFragments(player, SinType.WRATH, bonus);
                        NetworkHandler.sendFragmentSync(player);
                    }
                }
                LAST_KILL_TIME.put(player.method_5667(), now);
            }
        });
    }

    // ==================== LUST 色欲 — 繁殖与变异 ====================

    private static void registerLust() {
        // 繁殖由 MixinAnimalEntity 处理
        // 闪电变异由 MixinLightningStrike 处理
        // 僵尸村民治愈由 MixinZombieVillagerEntity 处理
        // 僵尸转溺尸由 MixinZombieEntity 处理

        // 使用物品：鸡蛋（5秒冷却）
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.field_9236) return class_1271.method_22430(player.method_5998(hand));
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7909() == class_1802.field_8803) {
                long now = world.method_8510();
                Long last = LAST_EGG_TIME.get(player.method_5667());
                if (last == null || now - last >= ModConfig.LUST_EGG_COOLDOWN_TICKS) {
                    LAST_EGG_TIME.put(player.method_5667(), now);
                    SinFragmentManager.addFragments((class_3222) player, SinType.LUST, ModConfig.LUST_EGG_AMOUNT);
                    NetworkHandler.sendFragmentSync((class_3222) player);
                }
            }
            return class_1271.method_22430(stack);
        });
    }

    private static void findNearbyPlayerAndAddLustFragment(class_1937 world, class_243 pos, int amount) {
        class_238 box = new class_238(pos.field_1352 - 16, pos.field_1351 - 16, pos.field_1350 - 16, pos.field_1352 + 16, pos.field_1351 + 16, pos.field_1350 + 16);
        for (class_1657 player : world.method_18456()) {
            if (player.method_19538().method_1022(pos) <= 16) {
                SinFragmentManager.addFragments((class_3222) player, SinType.LUST, amount);
                NetworkHandler.sendFragmentSync((class_3222) player);
            }
        }
    }

    // ==================== SLOTH 怠惰 — 静止与睡眠 ====================

    private static void registerSloth() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                UUID uuid = player.method_5667();
                class_243 pos = player.method_19538();
                class_243 last = LAST_POS.get(uuid);

                boolean moved = false;
                if (last != null) {
                    moved = Math.abs(pos.field_1352 - last.field_1352) > 0.001
                            || Math.abs(pos.field_1351 - last.field_1351) > 0.001
                            || Math.abs(pos.field_1350 - last.field_1350) > 0.001;
                }
                LAST_POS.put(uuid, pos);

                int ticks = AFK_TICKS.getOrDefault(uuid, 0);
                if (!moved && !player.method_5624() && player.method_24828()) {
                    ticks++;
                    if (ticks >= ModConfig.SLOTH_AFK_INTERVAL_TICKS) {
                        SinFragmentManager.addFragments(player, SinType.SLOTH, ModConfig.SLOTH_AFK_AMOUNT);
                        NetworkHandler.sendFragmentSync(player);
                        AFK_TICKS.put(uuid, 0);
                    } else {
                        AFK_TICKS.put(uuid, ticks);
                    }
                } else {
                    AFK_TICKS.put(uuid, 0);
                }
            }
        });

        // 睡眠完成由 MixinServerPlayerEntity.wakeUp() 注入处理
    }

    // ==================== GLUTTONY 暴食 — 进食 ====================

    private static void registerGluttony() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.field_9236) return class_1271.method_22430(player.method_5998(hand));
            class_1799 stack = player.method_5998(hand);
            if (stack.method_19267()) {
                SinFragmentManager.addFragments((class_3222) player, SinType.GLUTTONY, ModConfig.GLUTTONY_PER_FOOD);
                NetworkHandler.sendFragmentSync((class_3222) player);
            }
            return class_1271.method_22430(stack);
        });
    }

    // ==================== GLOOM 忧郁 — 受伤与目击 ====================

    private static void registerGloom() {
        // 玩家受到伤害时
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof class_3222 player) {
                int gloomFrag = (int) Math.ceil(amount / (double) ModConfig.GLOOM_DAMAGE_PER_FRAGMENT);
                if (gloomFrag > 0) {
                    SinFragmentManager.addFragments(player, SinType.GLOOM, gloomFrag * ModConfig.GLOOM_SELF_AMOUNT);
                    NetworkHandler.sendFragmentSync(player);
                }
            }
            return true;
        });

        // 目击其他生物受伤（每10点伤害 +1 忧郁碎片）
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity.method_37908().field_9236) return true;
            if (entity instanceof class_1657) return true;
            if (source.method_5529() instanceof class_1657) return true;

            int gloomFrag = (int) Math.ceil(amount / (double) ModConfig.GLOOM_DAMAGE_PER_FRAGMENT);
            if (gloomFrag <= 0) return true;

            class_238 box = entity.method_5829().method_1014(32);
            for (class_1657 player : entity.method_37908().method_18456()) {
                if (player.method_19538().method_1022(entity.method_19538()) <= 32) {
                    SinFragmentManager.addFragments((class_3222) player, SinType.GLOOM, gloomFrag * ModConfig.GLOOM_WITNESS_AMOUNT);
                    NetworkHandler.sendFragmentSync((class_3222) player);
                }
            }
            return true;
        });
    }

    // ==================== PRIDE 傲慢 — 成就与生产 ====================

    private static void registerPride() {
        // 每 tick 检测合成统计
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                int sum = 0;
                for (net.minecraft.class_1792 item : net.minecraft.class_7923.field_41178) {
                    sum += player.method_14248().method_15025(class_3468.field_15370.method_14956(item));
                }
                int prev = CRAFTED_COUNT.getOrDefault(player.method_5667(), 0);
                if (sum - prev >= ModConfig.PRIDE_CRAFT_THRESHOLD) {
                    int multiples = (sum - prev) / ModConfig.PRIDE_CRAFT_THRESHOLD;
                    SinFragmentManager.addFragments(player, SinType.PRIDE, multiples);
                    NetworkHandler.sendFragmentSync(player);
                    CRAFTED_COUNT.put(player.method_5667(), prev + multiples * ModConfig.PRIDE_CRAFT_THRESHOLD);
                } else if (prev == 0 && sum > 0) {
                    CRAFTED_COUNT.put(player.method_5667(), sum);
                }
            }
        });
    }

    // ==================== ENVY 嫉妒 — 攀比与目击 ====================

    /** 装备材质等级 */
    private static int getMaterialTier(class_1799 stack) {
        if (stack.method_7960()) return 0;
        class_1792 item = stack.method_7909();
        if (item instanceof class_1738 armor) {
            return getArmorMaterialTier(armor.method_7686());
        }
        if (item instanceof class_1831 tool) {
            return getToolMaterialTier(tool.method_8022());
        }
        return getItemTier(item);
    }

    private static int getArmorMaterialTier(class_1741 mat) {
        String name = mat.method_7694().toLowerCase();
        if (name.contains("netherite")) return 6;
        if (name.contains("diamond")) return 5;
        if (name.contains("gold") || name.contains("golden")) return 4;
        if (name.contains("iron")) return 3;
        if (name.contains("stone")) return 2;
        if (name.contains("wood") || name.contains("leather")) return 1;
        return 0;
    }

    private static int getToolMaterialTier(class_1832 mat) {
        String name = mat.toString().toLowerCase();
        if (name.contains("netherite")) return 6;
        if (name.contains("diamond")) return 5;
        if (name.contains("gold")) return 4;
        if (name.contains("iron")) return 3;
        if (name.contains("stone")) return 2;
        if (name.contains("wood")) return 1;
        return 0;
    }

    private static int getItemTier(class_1792 item) {
        String name = item.toString().toLowerCase();
        if (name.contains("netherite")) return 6;
        if (name.contains("diamond")) return 5;
        if (name.contains("gold")) return 4;
        if (name.contains("iron")) return 3;
        if (name.contains("stone")) return 2;
        if (name.contains("wood") || name.contains("leather")) return 1;
        return 0;
    }

    /** 检查装备是否有附魔 */
    private static boolean isEnchanted(class_1799 stack) {
        return stack.method_7942();
    }

    /** 获取玩家最佳装备等级 */
    private static int getPlayerBestTier(class_1657 player) {
        int best = 0;
        for (class_1799 armor : player.method_5661()) {
            // 物品等级 + 附魔加成
            int tier = getMaterialTier(armor);
            if (isEnchanted(armor)) tier += 10;
            if (tier > best) best = tier;
        }
        class_1799 mainHand = player.method_6047();
        int weaponTier = getMaterialTier(mainHand);
        if (isEnchanted(mainHand)) weaponTier += 10;
        if (weaponTier > best) best = weaponTier;
        return best;
    }

    private static void registerEnvy() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                UUID uuid = player.method_5667();
                int timer = ENVY_TIMER.getOrDefault(uuid, 0);
                timer++;
                if (timer >= ModConfig.ENVY_INTERVAL_TICKS) {
                    ENVY_TIMER.put(uuid, 0);
                    int myTier = getPlayerBestTier(player);
                    class_238 box = player.method_5829().method_1014(16);
                    for (class_1297 entity : player.method_37908().method_8333(player, box, e -> e instanceof class_1309)) {
                        if (entity instanceof class_1657 otherPlayer) {
                            int otherTier = getPlayerBestTier(otherPlayer);
                            if (otherTier > myTier) {
                                SinFragmentManager.addFragments(player, SinType.ENVY, ModConfig.ENVY_COMPARE_AMOUNT);
                                NetworkHandler.sendFragmentSync(player);
                                break;
                            }
                        }
                    }
                } else {
                    ENVY_TIMER.put(uuid, timer);
                }
            }
        });
    }

    /**
     * 通知附近玩家目击了罪孽攻击（ENVY +1）。
     * 由 MixinLivingEntity 在罪孽伤害计算时调用。
     *
     * @param world   当前世界
     * @param pos     攻击发生位置
     */
    public static void notifySinAttackWitnessed(class_1937 world, class_243 pos) {
        if (world.field_9236) return;
        class_238 box = new class_238(pos.field_1352 - 16, pos.field_1351 - 16, pos.field_1350 - 16, pos.field_1352 + 16, pos.field_1351 + 16, pos.field_1350 + 16);
        for (class_1657 player : world.method_18456()) {
            if (player.method_19538().method_1022(pos) <= 16) {
                SinFragmentManager.addFragments((class_3222) player, SinType.ENVY, ModConfig.ENVY_WITNESS_AMOUNT);
                NetworkHandler.sendFragmentSync((class_3222) player);
            }
        }
    }

    /**
     * 处理闪电变异导致的色欲碎片。
     * 由 Mixin 在实体被闪电击中时调用。
     *
     * @param world  当前世界
     * @param victim 被闪电击中的实体
     */
    public static void onLightningStrike(class_1937 world, class_1297 victim) {
        if (world.field_9236) return;
        boolean isTransformable = victim instanceof class_1452
                || victim instanceof class_1548
                || victim instanceof class_1438
                || victim instanceof class_1646;
        if (isTransformable) {
            findNearbyPlayerAndAddLustFragment(world, victim.method_19538(), ModConfig.LUST_LIGHTNING_AMOUNT);
        }
    }

    /**
     * 处理僵尸村民治愈（LUST +10）。
     */
    public static void onZombieVillagerCured(class_1937 world, class_243 pos) {
        if (world.field_9236) return;
        findNearbyPlayerAndAddLustFragment(world, pos, ModConfig.LUST_CURE_AMOUNT);
    }

    /**
     * 处理僵尸转溺尸（LUST +5）。
     */
    public static void onZombieConvertToDrowned(class_1937 world, class_243 pos) {
        if (world.field_9236) return;
        findNearbyPlayerAndAddLustFragment(world, pos, ModConfig.LUST_DROWN_AMOUNT);
    }

    /**
     * 处理动物繁殖成功（LUST +1）。
     */
    public static void onAnimalBreed(class_1937 world, class_243 pos) {
        if (world.field_9236) return;
        findNearbyPlayerAndAddLustFragment(world, pos, ModConfig.LUST_BREED_AMOUNT);
    }

    /**
     * 处理成就/进度达成（PRIDE +10）。
     */
    public static void onAdvancement(class_3222 player) {
        SinFragmentManager.addFragments(player, SinType.PRIDE, ModConfig.PRIDE_ACHIEVEMENT_AMOUNT);
        NetworkHandler.sendFragmentSync(player);
    }

    /**
     * 处理烧炼/酿造/附魔（PRIDE +2）。
     */
    public static void onProduction(class_3222 player) {
        SinFragmentManager.addFragments(player, SinType.PRIDE, ModConfig.PRIDE_PRODUCTION_AMOUNT);
        NetworkHandler.sendFragmentSync(player);
    }

    /**
     * 处理玩家从睡眠中醒来（SLOTH +5）。
     * 由 MixinServerPlayerEntity.wakeUp() 注入调用。
     */
    public static void onPlayerWakeUp(class_3222 player) {
        SinFragmentManager.addFragments(player, SinType.SLOTH, ModConfig.SLOTH_SLEEP_AMOUNT);
        NetworkHandler.sendFragmentSync(player);
    }
}