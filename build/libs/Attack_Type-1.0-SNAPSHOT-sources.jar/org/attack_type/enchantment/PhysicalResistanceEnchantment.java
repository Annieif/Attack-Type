package org.attack_type.enchantment;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import org.attack_type.api.AttackType;

public class PhysicalResistanceEnchantment extends class_1887 {
    private final AttackType attackType;

    public PhysicalResistanceEnchantment(AttackType attackType) {
        super(class_1888.field_9088, class_1886.field_9068, new class_1304[]{
                class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166});
        this.attackType = attackType;
    }

    public AttackType getAttackType() {
        return attackType;
    }

    public float getResistanceMultiplier(int level) {
        return 1.0f - level * 0.05f;
    }

    @Override
    public int method_8183() {
        return 4;
    }

    @Override
    public int method_8182(int level) {
        return 1 + (level - 1) * 8;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 15;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return true;
    }

    @Override
    public boolean method_25949() {
        return true;
    }

    @Override
    public boolean method_25950() {
        return true;
    }
}