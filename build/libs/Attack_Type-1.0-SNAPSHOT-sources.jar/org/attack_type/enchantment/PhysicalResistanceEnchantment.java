package org.attack_type.enchantment;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import org.attack_type.api.AttackType;

/**
 * 物理抗性护甲附魔。
 * <p>
 * 附在护甲上，降低受到的对应类型物理伤害。
 * 每级提供 5% 减伤，4 件护甲独立乘算。
 * <ul>
 *   <li>稀有度：RARE</li>
 *   <li>最高等级：4</li>
 *   <li>适用槽位：头盔、胸甲、护腿、靴子</li>
 *   <li>附魔台权重：1 + (level-1) × 8</li>
 *   <li>减伤公式：每件护甲提供 (1 - 0.05 × level)，4 件乘算</li>
 * </ul>
 */
public class PhysicalResistanceEnchantment extends class_1887 {
    private final AttackType attackType;

    /**
     * @param attackType 对应的攻击类型
     */
    public PhysicalResistanceEnchantment(AttackType attackType) {
        super(class_1888.field_9088, class_1886.field_9068, new class_1304[]{
                class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166});
        this.attackType = attackType;
    }

    /**
     * @return 此附魔对应的攻击类型
     */
    public AttackType getAttackType() {
        return attackType;
    }

    /**
     * 计算单件护甲的物理抗性乘数。
     *
     * @param level 附魔等级
     * @return 抗性乘数 = 1 - 0.05 × level
     */
    public float getResistanceMultiplier(int level) {
        return 1.0f - level * 0.05f;
    }

    @Override
    public int method_8183() {
        return 4;
    }

    @Override
    public int method_8182(int level) {
        return 1 + (level - 1) * 8;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 15;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return true;
    }

    @Override
    public boolean method_25949() {
        return true;
    }

    @Override
    public boolean method_25950() {
        return true;
    }
}