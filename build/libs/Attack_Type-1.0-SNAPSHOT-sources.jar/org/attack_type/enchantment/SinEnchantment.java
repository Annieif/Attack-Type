package org.attack_type.enchantment;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import org.attack_type.api.SinType;

/**
 * 罪孽武器附魔。
 * <p>
 * 附在武器上（主手），使攻击附带对应罪孽属性。
 * 玩家手持此附魔武器时，手动触发罪孽可减少碎片消耗（-2/级）。
 * 非玩家生物持有此附魔武器时，对应罪孽触发率 +10%/级。
 * <ul>
 *   <li>稀有度：RARE</li>
 *   <li>最高等级：5</li>
 *   <li>适用槽位：主手</li>
 *   <li>附魔台权重：1 + (level-1) × 10</li>
 * </ul>
 */
public class SinEnchantment extends class_1887 {
    private final SinType sinType;

    /**
     * @param sinType 对应的罪孽类型
     */
    public SinEnchantment(SinType sinType) {
        super(class_1888.field_9088, class_1886.field_9082, new class_1304[]{class_1304.field_6173});
        this.sinType = sinType;
    }

    /**
     * @return 此附魔对应的罪孽类型
     */
    public SinType getSinType() {
        return sinType;
    }

    @Override
    public int method_8183() {
        return 5;
    }

    @Override
    public int method_8182(int level) {
        return 1 + (level - 1) * 10;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 15;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return true;
    }

    @Override
    public boolean method_25949() {
        return true;
    }

    @Override
    public boolean method_25950() {
        return true;
    }
}