package org.attack_type.enchantment;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import org.attack_type.api.SinType;

public class SinEnchantment extends class_1887 {
    private final SinType sinType;

    public SinEnchantment(SinType sinType) {
        super(class_1888.field_9088, class_1886.field_9082, new class_1304[]{class_1304.field_6173});
        this.sinType = sinType;
    }

    public SinType getSinType() {
        return sinType;
    }

    @Override
    public int method_8183() {
        return 5;
    }

    @Override
    public int method_8182(int level) {
        return 1 + (level - 1) * 10;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 15;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return true;
    }

    @Override
    public boolean method_25949() {
        return true;
    }

    @Override
    public boolean method_25950() {
        return true;
    }
}