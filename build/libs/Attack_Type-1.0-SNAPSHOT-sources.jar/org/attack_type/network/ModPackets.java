package org.attack_type.network;

import net.minecraft.class_2960;
import org.attack_type.Attack_type;

public class ModPackets {
    public static final class_2960 RESISTANCE_SYNC = new class_2960(Attack_type.MOD_ID, "resistance_sync");
    public static final class_2960 RESISTANCE_UPDATE = new class_2960(Attack_type.MOD_ID, "resistance_update");
}