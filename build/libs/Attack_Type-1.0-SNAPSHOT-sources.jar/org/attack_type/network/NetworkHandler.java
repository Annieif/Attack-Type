package org.attack_type.network;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import org.attack_type.api.AttackType;
import org.attack_type.api.ResistanceProfile;
import org.attack_type.api.SinType;
import org.attack_type.component.ResistanceManager;

public class NetworkHandler {

    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(ModPackets.RESISTANCE_UPDATE,
                (server, player, handler, buf, responseSender) -> {
                    ResistanceProfile profile = new ResistanceProfile();
                    for (AttackType type : AttackType.values()) {
                        if (type != AttackType.NONE) {
                            profile.setPhysicalResistance(type, buf.readFloat());
                        }
                    }
                    for (SinType type : SinType.values()) {
                        profile.setSinResistance(type, buf.readFloat());
                    }
                    profile.setTotalProduct(buf.readFloat());
                    profile.normalize();
                    server.execute(() -> {
                        ResistanceManager.setProfile(player, profile);
                        sendResistanceSync(player);
                    });
                });
    }

    public static void sendResistanceSync(class_3222 player) {
        ResistanceProfile profile = ResistanceManager.getProfile(player);
        class_2540 buf = PacketByteBufs.create();
        buf.method_10794(profile.writeNbt(new net.minecraft.class_2487()));
        ServerPlayNetworking.send(player, ModPackets.RESISTANCE_SYNC, buf);
    }
}