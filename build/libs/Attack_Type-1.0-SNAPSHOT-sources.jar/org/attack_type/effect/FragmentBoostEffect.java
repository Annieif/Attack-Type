package org.attack_type.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * 碎片获取提升效果。
 * amplifier 0/1/2 对应 +1/+2/+3 额外碎片。
 */
public class FragmentBoostEffect extends class_1291 {
    public FragmentBoostEffect() {
        super(class_4081.field_18271, 0x44FF88);
    }

    public static int getExtraFragments(int amplifier) {
        return amplifier + 1;
    }
}