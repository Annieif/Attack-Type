package org.attack_type.effect;

import net.minecraft.class_1293;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1847;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.attack_type.api.SinType;

/**
 * 药水注册中心。
 * <p>
 * 注册 53 效果 × 3 级 = 159 个药水，以及对应的酿造配方。
 */
public class ModPotions {

    private static final int BASE_DURATION = 3600;
    private static final int EXTENDED_DURATION = 9600;

    public static void initialize() {
        registerSinPotions(SinType.WRATH, class_1802.field_8183);
        registerSinPotions(SinType.LUST, class_1802.field_17527);
        registerSinPotions(SinType.SLOTH, class_1802.field_8153);
        registerSinPotions(SinType.GLUTTONY, class_1802.field_8511);
        registerSinPotions(SinType.GLOOM, class_1802.field_8794);
        registerSinPotions(SinType.PRIDE, class_1802.field_8695);
        registerSinPotions(SinType.ENVY, class_1802.field_8687);

        registerPhysPotions(class_1802.field_8620);

        registerBurstPotions();

        registerGenericPotions();
    }

    private static void registerSinPotions(SinType sinType, net.minecraft.class_1792 ingredient) {
        String prefix = sinType.name().toLowerCase();
        SinCategoryEffect[] effects = {
                getSinEffect(sinType, EffectCategory.STRENGTHEN),
                getSinEffect(sinType, EffectCategory.GUARD),
                getSinEffect(sinType, EffectCategory.BOOST),
                getSinEffect(sinType, EffectCategory.WEAKEN),
                getSinEffect(sinType, EffectCategory.VULNERABLE),
                getSinEffect(sinType, EffectCategory.REDUCE)
        };
        String[] names = {"strengthen", "guard", "boost", "weaken", "vulnerable", "reduce"};

        for (int i = 0; i < effects.length; i++) {
            String id = prefix + "_" + names[i];
            class_1842 lv1 = register(id, new class_1842(new class_1293(effects[i], BASE_DURATION, 0)));
            class_1842 lv2 = register(id + "_strong", new class_1842(new class_1293(effects[i], BASE_DURATION, 1)));
            class_1842 lv3 = register(id + "_very_strong", new class_1842(new class_1293(effects[i], BASE_DURATION, 2)));
            class_1842 lv1Long = register(id + "_long", new class_1842(new class_1293(effects[i], EXTENDED_DURATION, 0)));

            class_1845.method_8074(class_1847.field_8999, ingredient, lv1);
            class_1845.method_8074(lv1, class_1802.field_8601, lv2);
            class_1845.method_8074(lv2, class_1802.field_8601, lv3);
            class_1845.method_8074(lv1, class_1802.field_8725, lv1Long);
        }
    }

    private static void registerPhysPotions(net.minecraft.class_1792 ingredient) {
        SinCategoryEffect[] effects = {
                ModStatusEffects.PHYSICAL_STRENGTHEN,
                ModStatusEffects.PHYSICAL_GUARD,
                ModStatusEffects.PHYSICAL_BOOST,
                ModStatusEffects.PHYSICAL_WEAKEN,
                ModStatusEffects.PHYSICAL_VULNERABLE,
                ModStatusEffects.PHYSICAL_REDUCE
        };
        String[] names = {"strengthen", "guard", "boost", "weaken", "vulnerable", "reduce"};

        for (int i = 0; i < effects.length; i++) {
            String id = "physical_" + names[i];
            class_1842 lv1 = register(id, new class_1842(new class_1293(effects[i], BASE_DURATION, 0)));
            class_1842 lv2 = register(id + "_strong", new class_1842(new class_1293(effects[i], BASE_DURATION, 1)));
            class_1842 lv3 = register(id + "_very_strong", new class_1842(new class_1293(effects[i], BASE_DURATION, 2)));
            class_1842 lv1Long = register(id + "_long", new class_1842(new class_1293(effects[i], EXTENDED_DURATION, 0)));

            class_1845.method_8074(class_1847.field_8999, ingredient, lv1);
            class_1845.method_8074(lv1, class_1802.field_8601, lv2);
            class_1845.method_8074(lv2, class_1802.field_8601, lv3);
            class_1845.method_8074(lv1, class_1802.field_8725, lv1Long);
        }
    }

    private static void registerBurstPotions() {
        SinType[] sins = SinType.values();
        BurstEffect[] effects = {
                ModStatusEffects.WRATH_BURST, ModStatusEffects.LUST_BURST,
                ModStatusEffects.SLOTH_BURST, ModStatusEffects.GLUTTONY_BURST,
                ModStatusEffects.GLOOM_BURST, ModStatusEffects.PRIDE_BURST,
                ModStatusEffects.ENVY_BURST
        };
        net.minecraft.class_1792[] ingredients = {
                class_1802.field_8183, class_1802.field_17527, class_1802.field_8153, class_1802.field_8511,
                class_1802.field_8794, class_1802.field_8695, class_1802.field_8687
        };

        for (int i = 0; i < sins.length; i++) {
            String id = "burst_" + sins[i].name().toLowerCase();
            class_1842[] levels = new class_1842[5];
            for (int lv = 0; lv < 5; lv++) {
                String suffix = lv == 0 ? "" : "_lv" + (lv + 1);
                levels[lv] = register(id + suffix, new class_1842(new class_1293(effects[i], BASE_DURATION, lv)));
            }
            class_1842 lv1Long = register(id + "_long", new class_1842(new class_1293(effects[i], EXTENDED_DURATION, 0)));

            class_1845.method_8074(class_1847.field_8999, ingredients[i], levels[0]);
            for (int lv = 0; lv < 4; lv++) {
                class_1845.method_8074(levels[lv], class_1802.field_8601, levels[lv + 1]);
            }
            class_1845.method_8074(levels[0], class_1802.field_8725, lv1Long);
        }
    }

    private static void registerGenericPotions() {
        registerGeneric("fragment_boost", ModStatusEffects.FRAGMENT_BOOST, 6000, class_1802.field_27063);
        registerGeneric("no_cost", ModStatusEffects.NO_COST, 1200, class_1802.field_8613);
        registerGeneric("ignore_resistance", ModStatusEffects.IGNORE_RESISTANCE, 2400, class_1802.field_22021);
        registerGeneric("fragment_drain", ModStatusEffects.FRAGMENT_DRAIN, 600, class_1802.field_17515);
        registerGeneric("cost_increase", ModStatusEffects.COST_INCREASE, BASE_DURATION, class_1802.field_8135);
    }

    private static void registerGeneric(String id, net.minecraft.class_1291 effect, int baseDuration, net.minecraft.class_1792 ingredient) {
        class_1842 lv1 = register(id, new class_1842(new class_1293(effect, baseDuration, 0)));
        class_1842 lv2 = register(id + "_strong", new class_1842(new class_1293(effect, baseDuration, 1)));
        class_1842 lv3 = register(id + "_very_strong", new class_1842(new class_1293(effect, baseDuration, 2)));
        class_1842 lv1Long = register(id + "_long", new class_1842(new class_1293(effect, baseDuration * 8 / 3, 0)));

        class_1845.method_8074(class_1847.field_8999, ingredient, lv1);
        class_1845.method_8074(lv1, class_1802.field_8601, lv2);
        class_1845.method_8074(lv2, class_1802.field_8601, lv3);
        class_1845.method_8074(lv1, class_1802.field_8725, lv1Long);
    }

    private static SinCategoryEffect getSinEffect(SinType sinType, EffectCategory category) {
        return switch (category) {
            case STRENGTHEN -> switch (sinType) {
                case WRATH -> ModStatusEffects.WRATH_STRENGTHEN;
                case LUST -> ModStatusEffects.LUST_STRENGTHEN;
                case SLOTH -> ModStatusEffects.SLOTH_STRENGTHEN;
                case GLUTTONY -> ModStatusEffects.GLUTTONY_STRENGTHEN;
                case GLOOM -> ModStatusEffects.GLOOM_STRENGTHEN;
                case PRIDE -> ModStatusEffects.PRIDE_STRENGTHEN;
                case ENVY -> ModStatusEffects.ENVY_STRENGTHEN;
            };
            case GUARD -> switch (sinType) {
                case WRATH -> ModStatusEffects.WRATH_GUARD;
                case LUST -> ModStatusEffects.LUST_GUARD;
                case SLOTH -> ModStatusEffects.SLOTH_GUARD;
                case GLUTTONY -> ModStatusEffects.GLUTTONY_GUARD;
                case GLOOM -> ModStatusEffects.GLOOM_GUARD;
                case PRIDE -> ModStatusEffects.PRIDE_GUARD;
                case ENVY -> ModStatusEffects.ENVY_GUARD;
            };
            case BOOST -> switch (sinType) {
                case WRATH -> ModStatusEffects.WRATH_BOOST;
                case LUST -> ModStatusEffects.LUST_BOOST;
                case SLOTH -> ModStatusEffects.SLOTH_BOOST;
                case GLUTTONY -> ModStatusEffects.GLUTTONY_BOOST;
                case GLOOM -> ModStatusEffects.GLOOM_BOOST;
                case PRIDE -> ModStatusEffects.PRIDE_BOOST;
                case ENVY -> ModStatusEffects.ENVY_BOOST;
            };
            case WEAKEN -> switch (sinType) {
                case WRATH -> ModStatusEffects.WRATH_WEAKEN;
                case LUST -> ModStatusEffects.LUST_WEAKEN;
                case SLOTH -> ModStatusEffects.SLOTH_WEAKEN;
                case GLUTTONY -> ModStatusEffects.GLUTTONY_WEAKEN;
                case GLOOM -> ModStatusEffects.GLOOM_WEAKEN;
                case PRIDE -> ModStatusEffects.PRIDE_WEAKEN;
                case ENVY -> ModStatusEffects.ENVY_WEAKEN;
            };
            case VULNERABLE -> switch (sinType) {
                case WRATH -> ModStatusEffects.WRATH_VULNERABLE;
                case LUST -> ModStatusEffects.LUST_VULNERABLE;
                case SLOTH -> ModStatusEffects.SLOTH_VULNERABLE;
                case GLUTTONY -> ModStatusEffects.GLUTTONY_VULNERABLE;
                case GLOOM -> ModStatusEffects.GLOOM_VULNERABLE;
                case PRIDE -> ModStatusEffects.PRIDE_VULNERABLE;
                case ENVY -> ModStatusEffects.ENVY_VULNERABLE;
            };
            case REDUCE -> switch (sinType) {
                case WRATH -> ModStatusEffects.WRATH_REDUCE;
                case LUST -> ModStatusEffects.LUST_REDUCE;
                case SLOTH -> ModStatusEffects.SLOTH_REDUCE;
                case GLUTTONY -> ModStatusEffects.GLUTTONY_REDUCE;
                case GLOOM -> ModStatusEffects.GLOOM_REDUCE;
                case PRIDE -> ModStatusEffects.PRIDE_REDUCE;
                case ENVY -> ModStatusEffects.ENVY_REDUCE;
            };
        };
    }

    private static class_1842 register(String id, class_1842 potion) {
        return class_2378.method_10230(class_7923.field_41179, new class_2960("attack_type", id), potion);
    }
}