package org.attack_type.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * 无视抗性效果。
 * amplifier 0/1/2 对应 20%/40%/60% 伤害无视抗性。
 */
public class IgnoreResistanceEffect extends class_1291 {
    public IgnoreResistanceEffect() {
        super(class_4081.field_18271, 0xFF4444);
    }

    public static float getIgnoreRatio(int amplifier) {
        return (amplifier + 1) * 0.2f;
    }
}