package org.attack_type.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * 消耗增加效果。
 * amplifier 0/1/2 对应 消耗 +20%/+40%/+60%。
 */
public class CostIncreaseEffect extends class_1291 {
    public CostIncreaseEffect() {
        super(class_4081.field_18272, 0x884400);
    }

    public static float getCostMultiplier(int amplifier) {
        return 1.0f + (amplifier + 1) * 0.2f;
    }
}