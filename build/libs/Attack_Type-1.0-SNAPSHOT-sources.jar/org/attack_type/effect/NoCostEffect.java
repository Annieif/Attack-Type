package org.attack_type.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * 无消耗效果。
 * amplifier 0/1/2 对应 30s/1min/2min。
 */
public class NoCostEffect extends class_1291 {
    public NoCostEffect() {
        super(class_4081.field_18271, 0xFFFF88);
    }
}