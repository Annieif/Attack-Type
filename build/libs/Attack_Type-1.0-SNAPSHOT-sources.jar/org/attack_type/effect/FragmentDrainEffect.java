package org.attack_type.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * 碎片扣除效果。
 * amplifier 0/1/2 对应 每 5s 扣除 1/2/3 碎片。
 */
public class FragmentDrainEffect extends class_1291 {
    public FragmentDrainEffect() {
        super(class_4081.field_18272, 0x884444);
    }

    public static int getDrainAmount(int amplifier) {
        return amplifier + 1;
    }
}