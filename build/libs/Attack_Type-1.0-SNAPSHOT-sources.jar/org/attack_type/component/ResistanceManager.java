package org.attack_type.component;

import org.attack_type.api.ResistanceProfile;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public class ResistanceManager {
    private static final Map<UUID, ResistanceProfile> PROFILES = new ConcurrentHashMap<>();
    public static final long UPDATE_INTERVAL_TICKS = 24000L * 2;

    public static ResistanceProfile getProfile(class_1309 entity) {
        return PROFILES.computeIfAbsent(entity.method_5667(), uuid -> {
            ResistanceProfile profile = new ResistanceProfile();
            if (entity instanceof class_1657) {
                profile.randomizeResistances();
                profile.normalize();
            }
            return profile;
        });
    }

    public static void setProfile(class_1309 entity, ResistanceProfile profile) {
        PROFILES.put(entity.method_5667(), profile);
    }

    public static void removeProfile(UUID uuid) {
        PROFILES.remove(uuid);
    }

    public static void tickEntityResistance(class_1309 entity, long worldTime) {
        if (entity instanceof class_1657) {
            return;
        }

        ResistanceProfile profile = getProfile(entity);
        long ticksSinceUpdate = worldTime - profile.getLastUpdateTick();

        if (ticksSinceUpdate >= UPDATE_INTERVAL_TICKS) {
            long periods = ticksSinceUpdate / UPDATE_INTERVAL_TICKS;
            profile.randomizeResistances();
            profile.normalize();

            long fullCycles = periods / 4;
            if (fullCycles > 0) {
                float newProduct = profile.getTotalProduct() - fullCycles * 0.01f;
                profile.setTotalProduct(Math.max(0.01f, newProduct));
                profile.normalize();
            }

            profile.setLastUpdateTick(worldTime);
        }
    }
}