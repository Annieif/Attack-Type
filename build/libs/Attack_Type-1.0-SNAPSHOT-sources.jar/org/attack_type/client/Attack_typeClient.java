package org.attack_type.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.attack_type.api.SinType;
import org.attack_type.fragment.ClientFragmentCache;
import org.attack_type.gui.ResistanceScreen;
import org.attack_type.gui.SinFragmentHUD;
import org.attack_type.network.NetworkHandlerClient;
import org.attack_type.network.ModPackets;
import org.lwjgl.glfw.GLFW;

/**
 * 客户端模组入口。
 * <p>
 * 注册按键绑定、HUD 渲染、网络包接收器和连接事件：
 * <ul>
 *   <li><b>U 键</b> — 打开抗性配置 GUI</li>
 *   <li><b>[ 键</b> — 向左切换激活罪孽</li>
 *   <li><b>] 键</b> — 向右切换激活罪孽</li>
 *   <li><b>\ 键</b> — 触发罪孽（连按 1~3 次选择 L1~L3）</li>
 * </ul>
 * <p>
 * 罪孽触发采用 20 tick 窗口缓冲：连按 N 次触发 Lv.N，超时后发送网络包。
 */
public class Attack_typeClient implements ClientModInitializer {
    private static class_304 resistanceKey;
    private static class_304 sinLeftKey;
    private static class_304 sinRightKey;
    private static class_304 sinTriggerKey;

    /** 触发键连按计数（1~3） */
    private static int triggerPressCount = 0;
    /** 触发窗口倒计时 */
    private static int triggerTimer = 0;
    /** 触发窗口长度（tick），连按窗口为 20 tick = 1 秒 */
    private static final int TRIGGER_WINDOW = 20;

    @Override
    public void onInitializeClient() {
        resistanceKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.attack_type.resistance",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_U,
                "category.attack_type"
        ));

        sinLeftKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.attack_type.sin_left",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_LEFT_BRACKET,
                "category.attack_type"
        ));

        sinRightKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.attack_type.sin_right",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_BRACKET,
                "category.attack_type"
        ));

        sinTriggerKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.attack_type.sin_trigger",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_BACKSLASH,
                "category.attack_type"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (resistanceKey.method_1436()) {
                class_310.method_1551().method_1507(new ResistanceScreen());
            }

            if (sinLeftKey.method_1436()) {
                cycleActiveSin(-1);
            }
            if (sinRightKey.method_1436()) {
                cycleActiveSin(1);
            }

            if (sinTriggerKey.method_1436()) {
                triggerPressCount = Math.min(triggerPressCount + 1, 3);
                triggerTimer = TRIGGER_WINDOW;
            }

            if (triggerTimer > 0) {
                triggerTimer--;
                if (triggerTimer == 0 && triggerPressCount > 0) {
                    sendTriggerPacket(triggerPressCount);
                    triggerPressCount = 0;
                }
            }
        });

        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            SinFragmentHUD.render(context);
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            triggerPressCount = 0;
            triggerTimer = 0;
        });

        NetworkHandlerClient.registerClient();
    }

    /**
     * 循环切换激活罪孽类型。
     *
     * @param direction -1 向左，+1 向右
     */
    private static void cycleActiveSin(int direction) {
        SinType[] types = SinType.values();
        SinType current = ClientFragmentCache.getActiveSinType();
        int idx = 0;
        for (int i = 0; i < types.length; i++) {
            if (types[i] == current) {
                idx = i;
                break;
            }
        }
        idx = (idx + direction + types.length) % types.length;
        ClientFragmentCache.setActiveSinType(types[idx]);
        showCycleMessage();
    }

    /**
     * 在 action bar 显示当前激活的罪孽名称。
     */
    private static void showCycleMessage() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            class_2561 sinName = class_2561.method_43471("sin.attack_type." + ClientFragmentCache.getActiveSinType().name().toLowerCase());
            client.field_1724.method_7353(
                    class_2561.method_43469("hud.attack_type.active_sin", sinName),
                    true
            );
        }
    }

    /**
     * 发送罪孽触发网络包到服务端。
     *
     * @param level 触发等级（1~3）
     */
    private static void sendTriggerPacket(int level) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(ClientFragmentCache.getActiveSinType().ordinal());
        buf.writeInt(level);
        ClientPlayNetworking.send(ModPackets.FRAGMENT_TRIGGER, buf);
    }
}