package org.attack_type.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.attack_type.gui.ResistanceScreen;
import org.attack_type.network.NetworkHandlerClient;
import org.lwjgl.glfw.GLFW;

public class Attack_typeClient implements ClientModInitializer {
    private static class_304 resistanceKey;

    @Override
    public void onInitializeClient() {
        resistanceKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.attack_type.resistance",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_U,
                "category.attack_type"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (resistanceKey.method_1436()) {
                class_310.method_1551().method_1507(new ResistanceScreen());
            }
        });

        NetworkHandlerClient.registerClient();
    }
}