package org.attack_type.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import org.attack_type.api.AttackType;
import org.attack_type.api.ResistanceProfile;
import org.attack_type.api.SinType;
import org.attack_type.component.ResistanceManager;
import org.attack_type.config.ModConfig;
import org.attack_type.fragment.SinFragmentData;
import org.attack_type.fragment.SinFragmentManager;
import org.attack_type.network.NetworkHandler;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1493;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * 攻击类型系统管理命令。
 * <p>
 * 注册 {@code /attacktype} 根命令（权限等级 2），包含以下子命令：
 * <ul>
 *   <li>{@code /attacktype get [target]} — 查看实体抗性</li>
 *   <li>{@code /attacktype set <type> <value> [target]} — 设置抗性值</li>
 *   <li>{@code /attacktype reset [target]} — 重置抗性为默认</li>
 *   <li>{@code /attacktype tick [target]} — 手动触发一次抗性衰减</li>
 *   <li>{@code /attacktype fragment get [target]} — 查看碎片数据</li>
 *   <li>{@code /attacktype fragment add <type> <amount> [target]} — 增加碎片</li>
 *   <li>{@code /attacktype fragment set <type> <amount> [target]} — 设置碎片</li>
 * </ul>
 */
public class ResistanceCommand {

    /**
     * 注册命令到调度器。
     *
     * @param dispatcher Minecraft 命令调度器
     */
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("attacktype")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9247("get")
                        .executes(ctx -> getResistance(ctx, ctx.getSource().method_9207()))
                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                .executes(ctx -> getResistance(ctx, class_2186.method_9313(ctx, "target")))))
                .then(class_2170.method_9247("set")
                        .then(class_2170.method_9244("type", StringArgumentType.word())
                                .suggests((ctx, builder) -> {
                                    for (AttackType type : AttackType.values()) {
                                        if (type != AttackType.NONE) builder.suggest(type.name().toLowerCase());
                                    }
                                    for (SinType type : SinType.values()) {
                                        builder.suggest(type.name().toLowerCase());
                                    }
                                    return builder.buildFuture();
                                })
                                .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg(0.0))
                                        .executes(ctx -> setResistance(ctx, ctx.getSource().method_9207()))
                                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                                .executes(ctx -> setResistance(ctx, class_2186.method_9313(ctx, "target")))))))
                .then(class_2170.method_9247("reset")
                        .executes(ctx -> resetResistance(ctx, ctx.getSource().method_9207()))
                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                .executes(ctx -> resetResistance(ctx, class_2186.method_9313(ctx, "target")))))
                .then(class_2170.method_9247("tick")
                        .executes(ctx -> tickResistance(ctx, ctx.getSource().method_9207()))
                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                .executes(ctx -> tickResistance(ctx, class_2186.method_9313(ctx, "target")))))
                .then(class_2170.method_9247("fragment")
                        .then(buildFragmentGet())
                        .then(buildFragmentAdd())
                        .then(buildFragmentSet())
                )
                .then(class_2170.method_9247("test")
                        .executes(ResistanceCommand::spawnTestDogs)
                )
                .then(class_2170.method_9247("reload")
                        .executes(ResistanceCommand::reloadConfig)
                )
        );
    }

    private static LiteralArgumentBuilder<class_2168> buildFragmentGet() {
        return class_2170.method_9247("get")
                .executes(ctx -> fragmentGet(ctx, ctx.getSource().method_9207()))
                .then(class_2170.method_9244("target", class_2186.method_9305())
                        .executes(ctx -> fragmentGet(ctx, class_2186.method_9315(ctx, "target"))));
    }

    private static LiteralArgumentBuilder<class_2168> buildFragmentAdd() {
        return class_2170.method_9247("add")
                .then(class_2170.method_9244("type", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            for (SinType type : SinType.values()) {
                                builder.suggest(type.name().toLowerCase());
                            }
                            return builder.buildFuture();
                        })
                        .then(class_2170.method_9244("amount", DoubleArgumentType.doubleArg())
                                .executes(ctx -> fragmentAdd(ctx, ctx.getSource().method_9207()))
                                .then(class_2170.method_9244("target", class_2186.method_9305())
                                        .executes(ctx -> fragmentAdd(ctx, class_2186.method_9315(ctx, "target"))))));
    }

    private static LiteralArgumentBuilder<class_2168> buildFragmentSet() {
        return class_2170.method_9247("set")
                .then(class_2170.method_9244("type", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            for (SinType type : SinType.values()) {
                                builder.suggest(type.name().toLowerCase());
                            }
                            return builder.buildFuture();
                        })
                        .then(class_2170.method_9244("amount", DoubleArgumentType.doubleArg())
                                .executes(ctx -> fragmentSet(ctx, ctx.getSource().method_9207()))
                                .then(class_2170.method_9244("target", class_2186.method_9305())
                                        .executes(ctx -> fragmentSet(ctx, class_2186.method_9315(ctx, "target"))))));
    }

    /**
     * 查看实体抗性信息。
     */
    private static int getResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43471("cmd.attack_type.err_not_living"));
            return 0;
        }

        ResistanceProfile profile = ResistanceManager.getOrCreateProfile(living);
        StringBuilder sb = new StringBuilder();
        sb.append(t("cmd.attack_type.get_title", entity.method_5477().getString())).append("\n");
        sb.append(t("cmd.attack_type.total_product", profile.getTotalProduct())).append("\n");
        sb.append(t("cmd.attack_type.physical_title")).append("\n");
        for (AttackType type : AttackType.values()) {
            if (type == AttackType.NONE) continue;
            float v = profile.getPhysicalResistance(type);
            sb.append(t("cmd.attack_type.resistance_row", t("attack_type.attack_type." + type.name().toLowerCase()), v, profile.getResistanceLabel(type))).append("\n");
        }
        sb.append(t("cmd.attack_type.sin_title")).append("\n");
        for (SinType type : SinType.values()) {
            float v = profile.getSinResistance(type);
            sb.append(t("cmd.attack_type.resistance_row", t("sin.attack_type." + type.name().toLowerCase()), v, profile.getResistanceLabel(type))).append("\n");
        }

        ctx.getSource().method_9226(() -> class_2561.method_43470(sb.toString()), false);
        return 1;
    }

    /**
     * 设置实体抗性值。
     */
    private static int setResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43471("cmd.attack_type.err_not_living"));
            return 0;
        }

        String typeName = StringArgumentType.getString(ctx, "type").toUpperCase();
        double value = DoubleArgumentType.getDouble(ctx, "value");

        ResistanceProfile profile = ResistanceManager.getOrCreateProfile(living);

        boolean found = false;
        for (AttackType type : AttackType.values()) {
            if (type.name().equalsIgnoreCase(typeName)) {
                profile.setPhysicalResistance(type, (float) value);
                found = true;
                break;
            }
        }
        if (!found) {
            for (SinType type : SinType.values()) {
                if (type.name().equalsIgnoreCase(typeName)) {
                    profile.setSinResistance(type, (float) value);
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            ctx.getSource().method_9213(class_2561.method_43469("cmd.attack_type.err_unknown_type", typeName));
            return 0;
        }

        if (living instanceof class_3222 player) {
            ResistanceManager.syncToPlayer(player);
        }

        String displayName = resolveTypeName(typeName);
        ctx.getSource().method_9226(() -> class_2561.method_43469("cmd.attack_type.set_ok", displayName, value, entity.method_5477().getString()), true);
        return 1;
    }

    /**
     * 重置实体抗性为默认值。
     */
    private static int resetResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43471("cmd.attack_type.err_not_living"));
            return 0;
        }

        ResistanceManager.resetProfile(living);
        if (living instanceof class_3222 player) {
            ResistanceManager.syncToPlayer(player);
        }

        ctx.getSource().method_9226(() -> class_2561.method_43469("cmd.attack_type.reset_ok", entity.method_5477().getString()), true);
        return 1;
    }

    /**
     * 手动触发一次实体抗性衰减。
     */
    private static int tickResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43471("cmd.attack_type.err_not_living"));
            return 0;
        }

        ResistanceManager.tickEntityResistance(living, living.method_37908().method_8510());
        if (living instanceof class_3222 player) {
            ResistanceManager.syncToPlayer(player);
        }

        ctx.getSource().method_9226(() -> class_2561.method_43469("cmd.attack_type.tick_ok", entity.method_5477().getString()), true);
        return 1;
    }

    /**
     * 查看玩家碎片数据。
     */
    private static int fragmentGet(CommandContext<class_2168> ctx, class_3222 target) {
        SinFragmentData data = SinFragmentManager.getData(target);
        StringBuilder sb = new StringBuilder();
        sb.append(t("cmd.attack_type.frag_title", target.method_5477().getString())).append("\n");
        for (SinType type : SinType.values()) {
            int count = data.getFragments(type);
            String row = t("cmd.attack_type.frag_row", t("sin.attack_type." + type.name().toLowerCase()), count).getString();
            sb.append(row);
            if (count >= 500) sb.append(t("cmd.attack_type.frag_overflow"));
            if (count >= 1000) sb.append(t("cmd.attack_type.frag_kill"));
            sb.append("\n");
        }
        String sinName = t("sin.attack_type." + data.getActiveSinType().name().toLowerCase()).getString();
        sb.append(t("cmd.attack_type.frag_active", sinName, data.getActiveSinLevel())).append("\n");
        ctx.getSource().method_9226(() -> class_2561.method_43470(sb.toString()), false);
        return 1;
    }

    /**
     * 增加玩家碎片。
     */
    private static int fragmentAdd(CommandContext<class_2168> ctx, class_3222 target) {
        String typeName = StringArgumentType.getString(ctx, "type").toUpperCase();
        int amount = (int) DoubleArgumentType.getDouble(ctx, "amount");

        SinType sinType = null;
        for (SinType type : SinType.values()) {
            if (type.name().equalsIgnoreCase(typeName)) {
                sinType = type;
                break;
            }
        }
        if (sinType == null) {
            ctx.getSource().method_9213(class_2561.method_43469("cmd.attack_type.err_unknown_sin", typeName));
            return 0;
        }

        SinFragmentManager.addFragments(target, sinType, amount);
        NetworkHandler.sendFragmentSync(target);
        int newCount = SinFragmentManager.getFragmentCount(target, sinType);
        String sinName = t("sin.attack_type." + sinType.name().toLowerCase()).getString();
        ctx.getSource().method_9226(() -> class_2561.method_43469("cmd.attack_type.frag_add_ok", amount, sinName, target.method_5477().getString(), newCount), true);
        return 1;
    }

    /**
     * 设置玩家碎片数量。
     */
    private static int fragmentSet(CommandContext<class_2168> ctx, class_3222 target) {
        String typeName = StringArgumentType.getString(ctx, "type").toUpperCase();
        int amount = (int) DoubleArgumentType.getDouble(ctx, "amount");

        SinType sinType = null;
        for (SinType type : SinType.values()) {
            if (type.name().equalsIgnoreCase(typeName)) {
                sinType = type;
                break;
            }
        }
        if (sinType == null) {
            ctx.getSource().method_9213(class_2561.method_43469("cmd.attack_type.err_unknown_sin", typeName));
            return 0;
        }

SinFragmentManager.getData(target).setFragments(sinType, amount);
        NetworkHandler.sendFragmentSync(target);
        String sinName = t("sin.attack_type." + sinType.name().toLowerCase()).getString();
        ctx.getSource().method_9226(() -> class_2561.method_43469("cmd.attack_type.frag_set_ok", sinName, target.method_5477().getString(), amount), true);
        return 1;
    }

    /**
     * 获取类型名称的国际化显示文本。
     */
    private static String resolveTypeName(String typeName) {
        for (AttackType type : AttackType.values()) {
            if (type.name().equalsIgnoreCase(typeName)) {
                return t("attack_type.attack_type." + type.name().toLowerCase()).getString();
            }
        }
        for (SinType type : SinType.values()) {
            if (type.name().equalsIgnoreCase(typeName)) {
                return t("sin.attack_type." + type.name().toLowerCase()).getString();
            }
        }
        return typeName;
    }

    /**
     * 生成测试狗（/attacktype test）。
     * <p>
     * 在玩家周围生成 10 只具有极端抗性值的测试狗，互相敌对，便于实验。
     * <ul>
     *   <li>#0: 全抗性 0.0（免疫）</li>
     *   <li>#1: 斩击 0.0，其他正常</li>
     *   <li>#2: 突刺 0.0，其他正常</li>
     *   <li>#3: 打击 0.0，其他正常</li>
     *   <li>#4: 暴怒罪孽 0.0</li>
     *   <li>#5: 全抗性 50.0（致命）</li>
     *   <li>#6: 全抗性 0.0, 总积 0.1</li>
     *   <li>#7: 斩击 100.0, 其他 0.01</li>
     *   <li>#8: 突刺 100.0, 其他 0.01</li>
     *   <li>#9: 打击 100.0, 其他 0.01</li>
     * </ul>
     */
    private static int spawnTestDogs(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_2338 pos = new class_2338((int)source.method_9222().field_1352, (int)source.method_9222().field_1351, (int)source.method_9222().field_1350);
        class_3218 world = source.method_9225();

        List<class_1493> dogs = new ArrayList<>();
        String[] names = {
            "All 0.0",
            "Slash 0.0",
            "Pierce 0.0",
            "Blunt 0.0",
            "Wrath 0.0",
            "All 50.0",
            "All 0.0 prod=0.1",
            "Slash 100",
            "Pierce 100",
            "Blunt 100"
        };

        for (int i = 0; i < 10; i++) {
            class_1493 wolf = new class_1493(net.minecraft.class_1299.field_6055, world);
            class_2338 spawnPos = pos.method_10069(i * 2, 0, 0);
            wolf.method_5808(spawnPos.method_10263() + 0.5, spawnPos.method_10264(), spawnPos.method_10260() + 0.5, 0, 0);
            wolf.method_5665(class_2561.method_43470(names[i]));
            wolf.method_5880(true);
            wolf.method_5971();
            wolf.method_6033(wolf.method_6063());

            ResistanceProfile profile = ResistanceManager.getOrCreateProfile(wolf);
            applyTestProfile(profile, i);
            world.method_8649(wolf);
            dogs.add(wolf);
        }

        for (class_1493 dog : dogs) {
            for (class_1493 other : dogs) {
                if (dog != other) {
                    dog.method_29513(other.method_5667());
                    dog.method_29514(Integer.MAX_VALUE);
                }
            }
        }

        source.method_9226(() -> class_2561.method_43469("cmd.attack_type.test_spawned", dogs.size()), true);
        return 1;
    }

    /**
     * 为测试狗应用极端抗性配置。
     *
     * @param profile 抗性配置
     * @param index   测试狗编号（0-9）
     */
    private static void applyTestProfile(ResistanceProfile profile, int index) {
        switch (index) {
            case 0:
                for (AttackType at : AttackType.values()) {
                    if (at != AttackType.NONE) profile.setPhysicalResistance(at, 0.0f);
                }
                for (SinType st : SinType.values()) {
                    profile.setSinResistance(st, 0.0f);
                }
                break;
            case 1:
                profile.setPhysicalResistance(AttackType.SLASH, 0.0f);
                break;
            case 2:
                profile.setPhysicalResistance(AttackType.PIERCE, 0.0f);
                break;
            case 3:
                profile.setPhysicalResistance(AttackType.BLUNT, 0.0f);
                break;
            case 4:
                profile.setSinResistance(SinType.WRATH, 0.0f);
                break;
            case 5:
                for (AttackType at : AttackType.values()) {
                    if (at != AttackType.NONE) profile.setPhysicalResistance(at, 50.0f);
                }
                for (SinType st : SinType.values()) {
                    profile.setSinResistance(st, 50.0f);
                }
                break;
            case 6:
                for (AttackType at : AttackType.values()) {
                    if (at != AttackType.NONE) profile.setPhysicalResistance(at, 0.0f);
                }
                for (SinType st : SinType.values()) {
                    profile.setSinResistance(st, 0.0f);
                }
                profile.setTotalProduct(0.1f);
                break;
            case 7:
                profile.setPhysicalResistance(AttackType.SLASH, 100.0f);
                profile.setPhysicalResistance(AttackType.PIERCE, 0.01f);
                profile.setPhysicalResistance(AttackType.BLUNT, 0.01f);
                for (SinType st : SinType.values()) {
                    profile.setSinResistance(st, 0.01f);
                }
                break;
            case 8:
                profile.setPhysicalResistance(AttackType.PIERCE, 100.0f);
                profile.setPhysicalResistance(AttackType.SLASH, 0.01f);
                profile.setPhysicalResistance(AttackType.BLUNT, 0.01f);
                for (SinType st : SinType.values()) {
                    profile.setSinResistance(st, 0.01f);
                }
                break;
            case 9:
                profile.setPhysicalResistance(AttackType.BLUNT, 100.0f);
                profile.setPhysicalResistance(AttackType.SLASH, 0.01f);
                profile.setPhysicalResistance(AttackType.PIERCE, 0.01f);
                for (SinType st : SinType.values()) {
                    profile.setSinResistance(st, 0.01f);
                }
                break;
        }
    }

    /**
     * 热重载配置。从外部 config/attack_type.json 或 jar 内 config.json 重新加载。
     */
    private static int reloadConfig(CommandContext<class_2168> ctx) {
        ModConfig.load();
        ctx.getSource().method_9226(
                () -> class_2561.method_43470("[AttackType] Configuration reloaded."), true);
        return 1;
    }

    /**
     * 翻译键辅助方法。
     */
    private static net.minecraft.class_5250 t(String key, Object... args) {
        return class_2561.method_43469(key, args);
    }
}