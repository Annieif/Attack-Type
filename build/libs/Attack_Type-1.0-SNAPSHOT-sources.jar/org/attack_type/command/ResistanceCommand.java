package org.attack_type.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.attack_type.api.AttackType;
import org.attack_type.api.ResistanceProfile;
import org.attack_type.api.SinType;
import org.attack_type.component.ResistanceManager;

public class ResistanceCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("attacktype")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9247("get")
                        .executes(ctx -> getResistance(ctx, ctx.getSource().method_9207()))
                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                .executes(ctx -> getResistance(ctx, class_2186.method_9313(ctx, "target")))))
                .then(class_2170.method_9247("set")
                        .then(class_2170.method_9244("type", StringArgumentType.word())
                                .suggests((ctx, builder) -> {
                                    for (AttackType type : AttackType.values()) {
                                        if (type != AttackType.NONE) builder.suggest(type.name().toLowerCase());
                                    }
                                    for (SinType type : SinType.values()) {
                                        builder.suggest(type.name().toLowerCase());
                                    }
                                    return builder.buildFuture();
                                })
                                .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg(0.0, 5.0))
                                        .executes(ctx -> setResistance(ctx, ctx.getSource().method_9207()))
                                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                                .executes(ctx -> setResistance(ctx, class_2186.method_9313(ctx, "target")))))))
                .then(class_2170.method_9247("reset")
                        .executes(ctx -> resetResistance(ctx, ctx.getSource().method_9207()))
                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                .executes(ctx -> resetResistance(ctx, class_2186.method_9313(ctx, "target")))))
                .then(class_2170.method_9247("tick")
                        .executes(ctx -> tickResistance(ctx, ctx.getSource().method_9207()))
                        .then(class_2170.method_9244("target", class_2186.method_9309())
                                .executes(ctx -> tickResistance(ctx, class_2186.method_9313(ctx, "target")))))
        );
    }

    private static int getResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43470("Target must be a living entity"));
            return 0;
        }

        ResistanceProfile profile = ResistanceManager.getOrCreateProfile(living);
        StringBuilder sb = new StringBuilder();
        sb.append("=== ").append(entity.method_5477().getString()).append(" ===\n");
        sb.append("Total Product: ").append(String.format("%.2f", profile.getTotalProduct())).append("\n");
        sb.append("Physical:\n");
        for (AttackType type : AttackType.values()) {
            if (type == AttackType.NONE) continue;
            float v = profile.getPhysicalResistance(type);
            sb.append("  ").append(type.name()).append(": ").append(String.format("%.2f", v))
                    .append(" (").append(profile.getResistanceLabel(type)).append(")\n");
        }
        sb.append("Sin:\n");
        for (SinType type : SinType.values()) {
            float v = profile.getSinResistance(type);
            sb.append("  ").append(type.name()).append(": ").append(String.format("%.2f", v))
                    .append(" (").append(profile.getResistanceLabel(type)).append(")\n");
        }

        ctx.getSource().method_9226(() -> class_2561.method_43470(sb.toString()), false);
        return 1;
    }

    private static int setResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43470("Target must be a living entity"));
            return 0;
        }

        String typeName = StringArgumentType.getString(ctx, "type").toUpperCase();
        double value = DoubleArgumentType.getDouble(ctx, "value");

        ResistanceProfile profile = ResistanceManager.getOrCreateProfile(living);

        boolean found = false;
        for (AttackType type : AttackType.values()) {
            if (type.name().equalsIgnoreCase(typeName)) {
                profile.setPhysicalResistance(type, (float) value);
                found = true;
                break;
            }
        }
        if (!found) {
            for (SinType type : SinType.values()) {
                if (type.name().equalsIgnoreCase(typeName)) {
                    profile.setSinResistance(type, (float) value);
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            ctx.getSource().method_9213(class_2561.method_43470("Unknown type: " + typeName + ". Use slash/pierce/blunt or sin names."));
            return 0;
        }

        if (living instanceof class_3222 player) {
            ResistanceManager.syncToPlayer(player);
        }

        ctx.getSource().method_9226(() -> class_2561.method_43470("Set " + typeName + " resistance to " + String.format("%.2f", value) + " for " + entity.method_5477().getString()), true);
        return 1;
    }

    private static int resetResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43470("Target must be a living entity"));
            return 0;
        }

        ResistanceManager.resetProfile(living);
        if (living instanceof class_3222 player) {
            ResistanceManager.syncToPlayer(player);
        }

        ctx.getSource().method_9226(() -> class_2561.method_43470("Reset resistance for " + entity.method_5477().getString()), true);
        return 1;
    }

    private static int tickResistance(CommandContext<class_2168> ctx, net.minecraft.class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            ctx.getSource().method_9213(class_2561.method_43470("Target must be a living entity"));
            return 0;
        }

        ResistanceManager.tickEntityResistance(living, living.method_37908().method_8510());
        if (living instanceof class_3222 player) {
            ResistanceManager.syncToPlayer(player);
        }

        ctx.getSource().method_9226(() -> class_2561.method_43470("Forced tick on " + entity.method_5477().getString()), true);
        return 1;
    }
}