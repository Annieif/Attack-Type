package org.attack_type.api;

import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1667;
import net.minecraft.class_1676;
import net.minecraft.class_1685;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import org.attack_type.enchantment.ModEnchantments;

public class AttackTypeMapper {

    public static AttackType getAttackType(class_1282 source) {
        if (source.method_5526() instanceof class_1676 projectile) {
            if (projectile instanceof class_1667 || projectile instanceof class_1685) {
                return AttackType.PIERCE;
            }
            return AttackType.BLUNT;
        }

        if (source.method_5526() instanceof class_1309 attacker) {
            class_1799 weapon = attacker.method_6047();
            if (weapon.method_7960()) {
                return AttackType.BLUNT;
            }

            String itemName = weapon.method_7909().toString().toLowerCase();
            if (itemName.contains("sword") || itemName.contains("axe") || itemName.contains("trident")) {
                return AttackType.SLASH;
            }

            return AttackType.BLUNT;
        }

        return AttackType.NONE;
    }

    public static SinType getSinType(class_1309 attacker) {
        class_1799 weapon = attacker.method_6047();
        if (weapon.method_7960()) {
            return null;
        }

        SinType bestSin = null;
        int bestLevel = 0;

        for (SinType sinType : SinType.values()) {
            class_1887 enchantment = ModEnchantments.getSinEnchantment(sinType);
            if (enchantment == null) continue;
            int level = class_1890.method_8225(enchantment, weapon);
            if (level > bestLevel) {
                bestLevel = level;
                bestSin = sinType;
            }
        }

        if (bestSin != null) {
            float probability = bestLevel * 0.1f;
            if (Math.random() < probability) {
                return bestSin;
            }
        }

        return null;
    }
}