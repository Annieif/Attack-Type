package org.attack_type.mixin;

import net.minecraft.class_1282;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2487;
import org.attack_type.api.AttackType;
import org.attack_type.api.AttackTypeMapper;
import org.attack_type.api.ResistanceProfile;
import org.attack_type.api.SinType;
import org.attack_type.component.ResistanceManager;
import org.attack_type.enchantment.ModEnchantments;
import org.attack_type.enchantment.PhysicalResistanceEnchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class MixinLivingEntity {

    @Unique
    private static final ThreadLocal<Float> PENDING_PHYS_MULT = new ThreadLocal<>();

    @Unique
    private static final ThreadLocal<Float> PENDING_SIN_DAMAGE = new ThreadLocal<>();

    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamageHead(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309) (Object) this;
        AttackType attackType = AttackTypeMapper.getAttackType(source);

        if (attackType == AttackType.NONE) {
            PENDING_PHYS_MULT.set(1.0f);
            PENDING_SIN_DAMAGE.set(0.0f);
            return;
        }

        ResistanceProfile profile = ResistanceManager.getProfile(self);
        float physResistance = profile.getPhysicalResistance(attackType);

        if (source.method_5526() instanceof class_1309 attacker) {
            physResistance *= getArmorResistance(self, attackType);
            SinType sinType = AttackTypeMapper.getSinType(attacker);
            if (sinType != null) {
                int sinLevel = class_1890.method_8225(
                        ModEnchantments.getSinEnchantment(sinType),
                        attacker.method_6047());
                float sinDamage = (sinLevel * 3.0f + 1.0f) * profile.getSinResistance(sinType);
                PENDING_SIN_DAMAGE.set(sinDamage);
            } else {
                PENDING_SIN_DAMAGE.set(0.0f);
            }
        } else {
            PENDING_SIN_DAMAGE.set(0.0f);
        }

        PENDING_PHYS_MULT.set(physResistance);
    }

    @ModifyArg(method = "damage",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;applyArmorToDamage(Lnet/minecraft/entity/damage/DamageSource;F)F"),
            index = 1)
    private float modifyArmorDamageArg(float amount) {
        Float mult = PENDING_PHYS_MULT.get();
        return amount * (mult != null ? mult : 1.0f);
    }

    @ModifyArg(method = "damage",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;applyDamage(Lnet/minecraft/entity/damage/DamageSource;F)V"),
            index = 1)
    private float addSinDamageToFinal(float amount) {
        Float sinDamage = PENDING_SIN_DAMAGE.get();
        PENDING_SIN_DAMAGE.remove();
        PENDING_PHYS_MULT.remove();
        return amount + (sinDamage != null ? sinDamage : 0.0f);
    }

    @Unique
    private float getArmorResistance(class_1309 entity, AttackType attackType) {
        PhysicalResistanceEnchantment enchantment = ModEnchantments.getPhysicalEnchantment(attackType);
        if (enchantment == null) return 1.0f;

        float totalReduction = 1.0f;
        for (class_1304 slot : class_1304.values()) {
            if (slot.method_5925() != class_1304.class_1305.field_6178) continue;
            class_1799 armor = entity.method_6118(slot);
            int level = class_1890.method_8225(enchantment, armor);
            if (level > 0) {
                totalReduction *= enchantment.getResistanceMultiplier(level);
            }
        }
        return totalReduction;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().field_9236) return;

        ResistanceManager.tickEntityResistance(self, self.method_37908().method_8510());
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("RETURN"))
    private void onWriteNbt(class_2487 nbt, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        ResistanceProfile profile = ResistanceManager.getProfile(self);
        nbt.method_10566("attack_type_resistance", profile.writeNbt(new class_2487()));
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("RETURN"))
    private void onReadNbt(class_2487 nbt, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (nbt.method_10545("attack_type_resistance")) {
            ResistanceProfile profile = ResistanceProfile.readNbt(nbt.method_10562("attack_type_resistance"));
            ResistanceManager.setProfile(self, profile);
        }
    }

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(class_1282 source, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        ResistanceManager.removeProfile(self.method_5667());
    }
}