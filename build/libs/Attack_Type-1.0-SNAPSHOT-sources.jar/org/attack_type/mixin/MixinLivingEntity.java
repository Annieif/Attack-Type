package org.attack_type.mixin;

import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1295;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5251;
import org.attack_type.advancement.ModAdvancements;
import org.attack_type.api.AttackType;
import org.attack_type.api.AttackTypeMapper;
import org.attack_type.api.ResistanceProfile;
import org.attack_type.api.SinType;
import org.attack_type.component.ResistanceManager;
import org.attack_type.enchantment.ModEnchantments;
import org.attack_type.enchantment.PhysicalResistanceEnchantment;
import org.attack_type.fragment.SinFragmentAcquisition;
import org.attack_type.fragment.SinFragmentData;
import org.attack_type.fragment.SinFragmentManager;
import org.attack_type.network.NetworkHandler;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * LivingEntity 伤害计算 Mixin 注入。
 * <p>
 * 通过三个注入点修改 Minecraft 原版伤害系统：
 * <ol>
 *   <li>{@code damage() HEAD} — 计算物理抗性乘数和罪孽附加伤害，存入 ThreadLocal</li>
 *   <li>{@code applyDamage()} INVOKE — 修改最终伤害值：{@code amount × physMult + sinDamage}</li>
 *   <li>{@code tick()} HEAD — 触发实体抗性周期衰减</li>
 * </ol>
 * 额外注入：NBT 读写持久化、死亡清理。
 *
 * <h3>伤害公式</h3>
 * <pre>
 * 最终伤害 = (物理伤害 × 物理抗性 × 护甲抗性附魔) × 原版护甲减伤 + (sinLevel × 3 + 1) × 罪孽抗性
 * </pre>
 * 其中 {@code applyDamage()} 修改的是传入原版护甲计算前的 amount，实际公式为：
 * <pre>
 * 最终伤害 = applyDamage(amount × physMult) + sinDamage
 * </pre>
 */
@Mixin(class_1309.class)
public abstract class MixinLivingEntity {

    /** 待应用的物理抗性乘数（ThreadLocal，跨 inject 传递） */
    @Unique
    private static final ThreadLocal<Float> PENDING_PHYS_MULT = new ThreadLocal<>();

    /** 待应用的罪孽附加伤害（ThreadLocal，跨 inject 传递） */
    @Unique
    private static final ThreadLocal<Float> PENDING_SIN_DAMAGE = new ThreadLocal<>();

    /**
     * 伤害计算入口（HEAD 注入）。
     * <p>
     * 步骤：
     * <ol>
     *   <li>判定攻击类型（NONE → 跳过所有计算）</li>
     *   <li>获取目标实体的物理抗性</li>
     *   <li>叠加护甲物理抗性附魔</li>
     *   <li>检查攻击者是否应被即死（碎片 ≥ 1000）</li>
     *   <li>判定罪孽属性 + 等级，计算附加伤害</li>
     *   <li>将结果存入 ThreadLocal 供 {@link #addSinDamageToFinal(float)} 使用</li>
     * </ol>
     *
     * @param source 伤害来源
     * @param amount 原始伤害值
     * @param cir    Mixin 回调
     */
    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamageHead(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309) (Object) this;
        AttackType attackType = AttackTypeMapper.getAttackType(source);

        if (attackType == AttackType.NONE) {
            PENDING_PHYS_MULT.set(1.0f);
            PENDING_SIN_DAMAGE.set(0.0f);
            return;
        }

        ResistanceProfile profile = ResistanceManager.getProfile(self);
        float physResistance = profile.getPhysicalResistance(attackType);

        if (source.method_5526() instanceof class_1309 attacker) {
            physResistance *= getArmorResistance(self, attackType);

            if (attacker instanceof class_1657 player && AttackTypeMapper.shouldKillPlayer(attacker)) {
                player.method_5768();
                PENDING_SIN_DAMAGE.set(0.0f);
                PENDING_PHYS_MULT.set(physResistance);
                if (player instanceof class_3222 sp) {
                    ModAdvancements.grant(sp, ModAdvancements.INSTANT_KILL);
                }
                return;
            }

            SinType sinType = AttackTypeMapper.getSinType(attacker);
            if (sinType != null) {
                int sinLevel = AttackTypeMapper.getSinLevel(attacker);
                float sinDamage = (sinLevel * 3.0f + 1.0f) * profile.getSinResistance(sinType);
                PENDING_SIN_DAMAGE.set(sinDamage);

                if (!self.method_37908().field_9236) {
                    class_3218 sw = (class_3218) self.method_37908();
                    spawnSinParticles(sw, self.method_23317(), self.method_23318() + self.method_17682() / 2, self.method_23321(), sinType, sinLevel);
                    SinFragmentAcquisition.notifySinAttackWitnessed(self.method_37908(), self.method_19538());

                    if (attacker instanceof class_3222 sp) {
                        ModAdvancements.recordSinTrigger(sp, sinType);
                    }

                    sw.method_43128(null, self.method_23317(), self.method_23318(), self.method_23321(),
                            class_3417.field_38830, class_3419.field_15251,
                            0.3f + 0.1f * sinLevel, 0.8f + 0.2f * sinLevel);

                    self.method_6092(new class_1293(
                            class_1294.field_5916, 20 * sinLevel, 0,
                            false, false, true));

                    spawnDamageNumber(sw, self.method_19538().method_1031(0, self.method_17682() + 0.5, 0),
                            sinType, sinDamage);
                }
            } else {
                PENDING_SIN_DAMAGE.set(0.0f);
            }
        } else {
            PENDING_SIN_DAMAGE.set(0.0f);
        }

        PENDING_PHYS_MULT.set(physResistance);
    }

    /**
     * 修改 applyDamage 的伤害参数（ModifyArg 注入）。
     * <p>
     * 将原始伤害乘以物理抗性乘数，再加上罪孽附加伤害。
     * 调用后清理所有 ThreadLocal 缓存。
     *
     * @param amount 原版计算的伤害值（已含护甲/保护等减伤）
     * @return 修改后的伤害值
     */
    @ModifyArg(method = "damage",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;applyDamage(Lnet/minecraft/entity/damage/DamageSource;F)V"),
            index = 1)
    private float addSinDamageToFinal(float amount) {
        Float mult = PENDING_PHYS_MULT.get();
        Float sinDamage = PENDING_SIN_DAMAGE.get();
        PENDING_SIN_DAMAGE.remove();
        PENDING_PHYS_MULT.remove();
        AttackTypeMapper.clearMobSinCache();
        return amount * (mult != null ? mult : 1.0f) + (sinDamage != null ? sinDamage : 0.0f);
    }

    /**
     * 计算护甲上的物理抗性附魔减伤。
     * <p>
     * 遍历 4 个护甲槽位，每个附魔等级提供 5% 减伤（乘算）：
     * 实际乘数 = ∏ (1 - 0.05 × level)。
     *
     * @param entity     目标实体
     * @param attackType 攻击类型
     * @return 护甲抗性乘数（≤ 1.0）
     */
    @Unique
    private float getArmorResistance(class_1309 entity, AttackType attackType) {
        PhysicalResistanceEnchantment enchantment = ModEnchantments.getPhysicalEnchantment(attackType);
        if (enchantment == null) return 1.0f;

        float totalReduction = 1.0f;
        for (class_1304 slot : class_1304.values()) {
            if (slot.method_5925() != class_1304.class_1305.field_6178) continue;
            class_1799 armor = entity.method_6118(slot);
            int level = class_1890.method_8225(enchantment, armor);
            if (level > 0) {
                totalReduction *= enchantment.getResistanceMultiplier(level);
            }
        }
        return totalReduction;
    }

    /**
     * 每 tick 触发实体抗性衰减（服务端）。
     */
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().field_9236) return;

        ResistanceManager.tickEntityResistance(self, self.method_37908().method_8510());
    }

    /**
     * 持久化抗性和碎片数据到 NBT。
     */
    @Inject(method = "writeCustomDataToNbt", at = @At("RETURN"))
    private void onWriteNbt(class_2487 nbt, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self instanceof class_1657) {
            ResistanceProfile profile = ResistanceManager.getProfile(self);
            nbt.method_10566("attack_type_resistance", profile.writeNbt(new class_2487()));
            SinFragmentData data = SinFragmentManager.getData((class_1657) self);
            nbt.method_10566("attack_type_fragments", data.writeNbt(new class_2487()));
        }
    }

    /**
     * 从 NBT 恢复抗性和碎片数据。
     */
    @Inject(method = "readCustomDataFromNbt", at = @At("RETURN"))
    private void onReadNbt(class_2487 nbt, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self instanceof class_1657) {
            if (nbt.method_10545("attack_type_resistance")) {
                ResistanceProfile profile = ResistanceProfile.readNbt(nbt.method_10562("attack_type_resistance"));
                ResistanceManager.setProfile(self, profile);
            }
            if (nbt.method_10545("attack_type_fragments")) {
                SinFragmentData data = new SinFragmentData();
                data.readNbt(nbt.method_10562("attack_type_fragments"));
                SinFragmentManager.setData(self.method_5667(), data);
            }
            if (self instanceof class_3222 sp) {
                NetworkHandler.sendResistanceSync(sp);
                NetworkHandler.sendFragmentSync(sp);
            }
        }
    }

    /**
     * 实体死亡时清理抗性数据。
     */
    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(class_1282 source, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        ResistanceManager.removeProfile(self.method_5667());
    }

    /**
     * 罪孽攻击粒子效果。
     * <p>
     * 每种罪孽使用不同颜色的 DustParticleEffect（RGB 粉尘粒子）：
     * <ul>
     *   <li>暴怒 WRATH — 红色 (1.0, 0.2, 0.2)</li>
     *   <li>色欲 LUST — 橙色 (1.0, 0.5, 0.0)</li>
     *   <li>怠惰 SLOTH — 黄色 (1.0, 0.9, 0.1)</li>
     *   <li>暴食 GLUTTONY — 草绿 (0.2, 0.8, 0.2)</li>
     *   <li>忧郁 GLOOM — 天蓝 (0.2, 0.7, 1.0)</li>
     *   <li>傲慢 PRIDE — 深蓝 (0.1, 0.2, 0.8)</li>
     *   <li>嫉妒 ENVY — 紫色 (0.6, 0.2, 1.0)</li>
     * </ul>
     * 粒子数量与大小随等级递增：
     * <ul>
     *   <li>Lv.1 — 8 粒子, size 0.6</li>
     *   <li>Lv.2 — 16 粒子, size 1.2</li>
     *   <li>Lv.3 — 24 粒子, size 1.8</li>
     * </ul>
     *
     * @param world    服务端世界
     * @param x        目标 X 坐标
     * @param y        目标 Y 坐标（身体中心）
     * @param z        目标 Z 坐标
     * @param sinType  罪孽类型
     * @param sinLevel 罪孽等级（1/2/3）
     */
    @Unique
    private static void spawnSinParticles(class_3218 world, double x, double y, double z, SinType sinType, int sinLevel) {
        Vector3f color = switch (sinType) {
            case WRATH -> new Vector3f(1.0f, 0.2f, 0.2f);     // 红
            case LUST -> new Vector3f(1.0f, 0.5f, 0.0f);       // 橙
            case SLOTH -> new Vector3f(1.0f, 0.9f, 0.1f);      // 黄
            case GLUTTONY -> new Vector3f(0.2f, 0.8f, 0.2f);   // 草绿
            case GLOOM -> new Vector3f(0.2f, 0.7f, 1.0f);      // 天蓝
            case PRIDE -> new Vector3f(0.1f, 0.2f, 0.8f);      // 深蓝
            case ENVY -> new Vector3f(0.6f, 0.2f, 1.0f);       // 紫
        };
        int particleCount = 4 + sinLevel * 4;
        float particleSize = 0.3f + sinLevel * 0.3f;
        float spread = 0.5f + sinLevel * 0.2f;
        class_2390 effect = new class_2390(color, particleSize);
        for (int i = 0; i < particleCount; i++) {
            double ox = x + (world.field_9229.method_43058() - 0.5) * spread;
            double oy = y + (world.field_9229.method_43058() - 0.5) * spread;
            double oz = z + (world.field_9229.method_43058() - 0.5) * spread;
            world.method_14199(effect, ox, oy, oz, 1, 0, 0, 0, 0);
        }
    }

    /**
     * 生成浮动伤害数字。
     * <p>
     * 使用 {@link class_1295} + 自定义名称在目标头顶显示罪孽伤害数值，
     * 文字颜色与罪孽类型对应，1 秒后自动消失。
     */
    @Unique
    private static void spawnDamageNumber(class_3218 world, class_243 pos, SinType sinType, float damage) {
        class_1295 cloud = new class_1295(world, pos.field_1352, pos.field_1351, pos.field_1350);
        int colorRgb = switch (sinType) {
            case WRATH -> 0xFF3333;
            case LUST -> 0xFF8000;
            case SLOTH -> 0xFFE600;
            case GLUTTONY -> 0x33CC33;
            case GLOOM -> 0x33B3FF;
            case PRIDE -> 0x1A33CC;
            case ENVY -> 0x9933FF;
        };
        cloud.method_5665(class_2561.method_43470(String.format("%.1f", damage))
                .method_27694(style -> style.method_27703(class_5251.method_27717(colorRgb))));
        cloud.method_5880(true);
        cloud.method_5604(20);
        cloud.method_5603(0.0f);
        cloud.method_5875(true);
        world.method_8649(cloud);
    }
}