package org.attack_type.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1538;
import net.minecraft.class_3218;
import org.attack_type.fragment.SinFragmentAcquisition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 闪电击中实体 Mixin。
 * <p>
 * 检测实体被闪电击中事件，通知 {@link SinFragmentAcquisition#onLightningStrike} 处理色欲碎片。
 * 变异的实体：猪、苦力怕、哞菇、村民。
 * <p>
 * 注意：{@code onStruckByLightning} 定义在 {@link class_1297} 中，因此 Mixin 目标为 Entity 而非 LivingEntity。
 */
@Mixin(class_1297.class)
public class MixinLightningStrike {

    /**
     * 实体被闪电击中时触发色欲碎片检测。
     */
    @Inject(method = "onStruckByLightning", at = @At("HEAD"))
    private void onLightningStrike(class_3218 world, class_1538 lightning, CallbackInfo ci) {
        class_1297 self = (class_1297) (Object) this;
        SinFragmentAcquisition.onLightningStrike(world, self);
    }
}