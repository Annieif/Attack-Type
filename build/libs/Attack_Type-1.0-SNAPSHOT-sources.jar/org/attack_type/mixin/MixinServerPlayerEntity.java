package org.attack_type.mixin;

import net.minecraft.class_2338;
import net.minecraft.class_3222;
import org.attack_type.fragment.SinFragmentAcquisition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 怠惰特性 Mixin。
 * <p>
 * 允许玩家在任何时间反复睡觉，不受白天/夜晚限制。
 * 注入 {@link class_3222#method_7269(class_2338)} 方法，绕过时间检查。
 * 注入 {@link class_3222#method_7358(boolean, boolean)} 方法，检测睡眠完成。
 */
@Mixin(class_3222.class)
public class MixinServerPlayerEntity {

    /**
     * 修改 trySleep 方法，允许白天睡觉和反复睡觉。
     */
    @Inject(method = "trySleep", at = @At("HEAD"), cancellable = true)
    private void allowAlwaysSleep(class_2338 pos, CallbackInfoReturnable<net.minecraft.class_1657.class_1658> cir) {
        class_3222 self = (class_3222) (Object) this;
        if (!self.method_37908().field_9236) {
            self.method_18403(pos);
            self.method_26284(self.method_37908().method_27983(), pos, 0.0f, false, true);
            cir.setReturnValue(null);
        }
    }

    /**
     * 检测玩家从睡眠中醒来，触发怠惰碎片 +5。
     */
    @Inject(method = "wakeUp", at = @At("RETURN"))
    private void onWakeUp(boolean skipSleepTimer, boolean updateSleepingPlayers, CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        if (!self.method_37908().field_9236) {
            SinFragmentAcquisition.onPlayerWakeUp(self);
        }
    }
}