package org.attack_type.mixin;

import net.minecraft.class_1299;
import net.minecraft.class_1642;
import net.minecraft.class_3218;
import org.attack_type.fragment.SinFragmentAcquisition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 僵尸转化 Mixin。
 * <p>
 * 检测僵尸转化为溺尸的事件，通知 {@link SinFragmentAcquisition#onZombieConvertToDrowned} 处理色欲碎片。
 * 每次转化 +5 色欲碎片。
 */
@Mixin(class_1642.class)
public class MixinZombieEntity {

    /**
     * 僵尸转化为溺尸时触发色欲碎片。
     */
    @Inject(method = "convertTo", at = @At("RETURN"))
    private void onConvertTo(class_1299<?> entityType, CallbackInfo ci) {
        class_1642 self = (class_1642) (Object) this;
        if (entityType == class_1299.field_6123 && self.method_37908() instanceof class_3218 world) {
            SinFragmentAcquisition.onZombieConvertToDrowned(world, self.method_19538());
        }
    }
}