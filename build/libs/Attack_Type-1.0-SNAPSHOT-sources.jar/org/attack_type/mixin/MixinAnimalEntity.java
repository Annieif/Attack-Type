package org.attack_type.mixin;

import net.minecraft.class_1429;
import net.minecraft.class_3218;
import org.attack_type.fragment.SinFragmentAcquisition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 动物繁殖 Mixin。
 * <p>
 * 检测动物繁殖成功事件，通知 {@link SinFragmentAcquisition#onAnimalBreed} 处理色欲碎片。
 * 每次繁殖成功 +1 色欲碎片。
 */
@Mixin(class_1429.class)
public class MixinAnimalEntity {

    /**
     * 繁殖成功时触发色欲碎片。
     */
    @Inject(method = "breed", at = @At("HEAD"))
    private void onBreed(class_3218 world, class_1429 other, CallbackInfo ci) {
        class_1429 self = (class_1429) (Object) this;
        SinFragmentAcquisition.onAnimalBreed(world, self.method_19538());
    }
}